export type FieldType = 'text' | 'number' | 'boolean'

export type GeneratorField = {
  id: string
  label: string
  type: FieldType
  default: string | number | boolean
  hint?: string
  min?: number
  step?: number
}

export type GeneratedFile = { name: string; location: string; scriptType: 'Script' | 'LocalScript'; code: string }

export type ScriptTemplate = {
  id: string
  name: string
  description: string
  fields: GeneratorField[]
  setup: string[]
  build: (v: Record<string, string | number | boolean>) => GeneratedFile[]
}

const ident = (s: unknown, fallback: string) => {
  const clean = String(s ?? '').replace(/[^A-Za-z0-9_]/g, '')
  return /^[A-Za-z_]/.test(clean) ? clean : fallback
}
const num = (v: unknown, fallback: number) => {
  const n = Number(v)
  return Number.isFinite(n) ? n : fallback
}
const header = (title: string, location: string) =>
  `--[[
	${title}
	المكان: ${location}
	تم التوليد محلياً بواسطة نَواة AI
]]
`

function dataStoreBlock(storeName: string) {
  return `local DataStoreService = game:GetService("DataStoreService")
local dataStore = DataStoreService:GetDataStore("${storeName}")

local function loadData(player)
	local ok, result = pcall(function()
		return dataStore:GetAsync("Player_" .. player.UserId)
	end)
	if not ok then
		warn("فشل تحميل بيانات " .. player.Name .. ": " .. tostring(result))
		return nil
	end
	return result
end

local function saveData(player, data)
	local ok, err = pcall(function()
		dataStore:SetAsync("Player_" .. player.UserId, data)
	end)
	if not ok then
		warn("فشل حفظ بيانات " .. player.Name .. ": " .. tostring(err))
	end
end
`
}

export const SCRIPT_TEMPLATES: ScriptTemplate[] = [
  {
    id: 'leaderstats',
    name: 'Leaderstats',
    description: 'لوحة إحصائيات اللاعبين مع حفظ تلقائي ودخل دوري',
    fields: [
      { id: 'currency', label: 'اسم العملة', type: 'text', default: 'Coins' },
      { id: 'startValue', label: 'القيمة الابتدائية', type: 'number', default: 0, min: 0 },
      { id: 'secondStat', label: 'إحصائية ثانية (اتركها فارغة للإلغاء)', type: 'text', default: 'Wins' },
      { id: 'autoIncome', label: 'دخل تلقائي', type: 'boolean', default: true },
      { id: 'incomeAmount', label: 'مقدار الدخل', type: 'number', default: 5, min: 1 },
      { id: 'incomeInterval', label: 'كل (ثانية)', type: 'number', default: 10, min: 1 },
      { id: 'useDataStore', label: 'حفظ البيانات (DataStore)', type: 'boolean', default: true },
    ],
    setup: [
      'افتح ServerScriptService وأنشئ Script جديد باسم Leaderstats.',
      'إذا فعّلت الحفظ: Game Settings › Security › فعّل Enable Studio Access to API Services.',
      'اضغط Play وستظهر الإحصائيات أعلى يمين الشاشة.',
    ],
    build: (v) => {
      const currency = ident(v.currency, 'Coins')
      const second = String(v.secondStat ?? '').trim() ? ident(v.secondStat, 'Wins') : ''
      const start = num(v.startValue, 0)
      const ds = Boolean(v.useDataStore)
      const income = Boolean(v.autoIncome)
      const stats = [currency, ...(second ? [second] : [])]

      const code = `${header('نظام Leaderstats', 'ServerScriptService')}
local Players = game:GetService("Players")
${ds ? '\n' + dataStoreBlock('PlayerStats_v1') : ''}
local DEFAULTS = {
${stats.map((s, i) => `	${s} = ${i === 0 ? start : 0},`).join('\n')}
}
${income ? `local INCOME_AMOUNT = ${num(v.incomeAmount, 5)}\nlocal INCOME_INTERVAL = ${num(v.incomeInterval, 10)}\n` : ''}
local function createLeaderstats(player)
	local leaderstats = Instance.new("Folder")
	leaderstats.Name = "leaderstats"
${ds ? '\n	local saved = loadData(player) or {}\n' : ''}
	for statName, defaultValue in pairs(DEFAULTS) do
		local stat = Instance.new("IntValue")
		stat.Name = statName
		stat.Value = ${ds ? 'saved[statName] or defaultValue' : 'defaultValue'}
		stat.Parent = leaderstats
	end

	leaderstats.Parent = player
end
${
  ds
    ? `
local function collectData(player)
	local leaderstats = player:FindFirstChild("leaderstats")
	if not leaderstats then return nil end

	local data = {}
	for _, stat in ipairs(leaderstats:GetChildren()) do
		if stat:IsA("IntValue") then
			data[stat.Name] = stat.Value
		end
	end
	return data
end

Players.PlayerRemoving:Connect(function(player)
	local data = collectData(player)
	if data then
		saveData(player, data)
	end
end)

game:BindToClose(function()
	for _, player in ipairs(Players:GetPlayers()) do
		local data = collectData(player)
		if data then
			saveData(player, data)
		end
	end
end)
`
    : ''
}
Players.PlayerAdded:Connect(createLeaderstats)
${
  income
    ? `
while true do
	task.wait(INCOME_INTERVAL)
	for _, player in ipairs(Players:GetPlayers()) do
		local leaderstats = player:FindFirstChild("leaderstats")
		local stat = leaderstats and leaderstats:FindFirstChild("${currency}")
		if stat then
			stat.Value += INCOME_AMOUNT
		end
	end
end
`
    : ''
}`
      return [{ name: 'Leaderstats', location: 'ServerScriptService', scriptType: 'Script', code: code.replace(/\n{3,}/g, '\n\n') }]
    },
  },
  {
    id: 'checkpoint',
    name: 'Checkpoint',
    description: 'نقاط حفظ لألعاب الأوبي مع مراحل وإعادة الظهور',
    fields: [
      { id: 'folderName', label: 'اسم مجلد النقاط في Workspace', type: 'text', default: 'Checkpoints' },
      { id: 'statName', label: 'اسم إحصائية المرحلة', type: 'text', default: 'Stage' },
      { id: 'allowSkip', label: 'السماح بتخطي المراحل', type: 'boolean', default: false },
      { id: 'highlight', label: 'تلوين النقطة عند الوصول', type: 'boolean', default: true },
      { id: 'useDataStore', label: 'حفظ التقدم (DataStore)', type: 'boolean', default: true },
    ],
    setup: [
      'أنشئ Folder في Workspace بنفس الاسم الذي اخترته.',
      'ضع داخله Parts مسماة بالأرقام: 1، 2، 3 … (النقطة 1 هي البداية).',
      'اجعل جميع الأجزاء Anchored، ثم ضع السكربت في ServerScriptService.',
    ],
    build: (v) => {
      const folder = ident(v.folderName, 'Checkpoints')
      const stat = ident(v.statName, 'Stage')
      const ds = Boolean(v.useDataStore)
      const skip = Boolean(v.allowSkip)
      const highlight = Boolean(v.highlight)

      const code = `${header('نظام Checkpoints للأوبي', 'ServerScriptService')}
local Players = game:GetService("Players")
${ds ? '\n' + dataStoreBlock('ObbyProgress_v1') : ''}
local checkpoints = workspace:WaitForChild("${folder}")

local function getCheckpoint(stage)
	return checkpoints:FindFirstChild(tostring(stage))
end

local function spawnAtCheckpoint(player, character)
	local stageValue = player:WaitForChild("leaderstats"):WaitForChild("${stat}")
	local checkpoint = getCheckpoint(stageValue.Value)
	if not checkpoint then return end

	character:WaitForChild("HumanoidRootPart")
	task.wait()
	character:PivotTo(checkpoint.CFrame + Vector3.new(0, 3, 0))
end

Players.PlayerAdded:Connect(function(player)
	local leaderstats = player:FindFirstChild("leaderstats") or Instance.new("Folder")
	leaderstats.Name = "leaderstats"

	local stage = Instance.new("IntValue")
	stage.Name = "${stat}"
	stage.Value = ${ds ? '(loadData(player) or 1)' : '1'}
	stage.Parent = leaderstats
	leaderstats.Parent = player

	player.CharacterAdded:Connect(function(character)
		spawnAtCheckpoint(player, character)
	end)

	if player.Character then
		spawnAtCheckpoint(player, player.Character)
	end
end)
${
  ds
    ? `
local function saveStage(player)
	local leaderstats = player:FindFirstChild("leaderstats")
	local stage = leaderstats and leaderstats:FindFirstChild("${stat}")
	if stage then
		saveData(player, stage.Value)
	end
end

Players.PlayerRemoving:Connect(saveStage)

game:BindToClose(function()
	for _, player in ipairs(Players:GetPlayers()) do
		saveStage(player)
	end
end)
`
    : ''
}
for _, checkpoint in ipairs(checkpoints:GetChildren()) do
	local stageNumber = tonumber(checkpoint.Name)
	if checkpoint:IsA("BasePart") and stageNumber then
		checkpoint.Touched:Connect(function(hit)
			local player = Players:GetPlayerFromCharacter(hit.Parent)
			if not player then return end

			local humanoid = hit.Parent:FindFirstChildOfClass("Humanoid")
			if not humanoid or humanoid.Health <= 0 then return end

			local stage = player.leaderstats.${stat}
			if ${skip ? 'stageNumber > stage.Value' : 'stageNumber == stage.Value + 1'} then
				stage.Value = stageNumber
${
  highlight
    ? `				local originalColor = checkpoint.Color
				checkpoint.Color = Color3.fromRGB(34, 211, 238)
				task.delay(0.6, function()
					checkpoint.Color = originalColor
				end)
`
    : ''
}			end
		end)
	end
end
`
      return [{ name: 'Checkpoints', location: 'ServerScriptService', scriptType: 'Script', code: code.replace(/\n{3,}/g, '\n\n') }]
    },
  },
  {
    id: 'rebirth',
    name: 'Rebirth System',
    description: 'نظام إعادة الولادة مع تكلفة متصاعدة ومضاعف أرباح',
    fields: [
      { id: 'currency', label: 'اسم العملة', type: 'text', default: 'Coins' },
      { id: 'baseCost', label: 'تكلفة أول Rebirth', type: 'number', default: 1000, min: 1 },
      { id: 'costMultiplier', label: 'مضاعف التكلفة', type: 'number', default: 2, min: 1, step: 0.1 },
      { id: 'rewardMultiplier', label: 'زيادة المضاعف لكل Rebirth', type: 'number', default: 0.5, min: 0.1, step: 0.1 },
      { id: 'resetCurrency', label: 'تصفير العملة بعد Rebirth', type: 'boolean', default: true },
      { id: 'useDataStore', label: 'حفظ البيانات (DataStore)', type: 'boolean', default: true },
    ],
    setup: [
      'ضع السكربت الأول (Server) في ServerScriptService — سينشئ RemoteEvent تلقائياً.',
      'أنشئ ScreenGui في StarterGui وبداخله TextButton.',
      'ضع السكربت الثاني (LocalScript) داخل TextButton.',
      'لإضافة أرباح مضاعفة استخدم: player:GetAttribute("Multiplier") في سكربتات الجمع.',
    ],
    build: (v) => {
      const currency = ident(v.currency, 'Coins')
      const ds = Boolean(v.useDataStore)
      const reset = Boolean(v.resetCurrency)

      const server = `${header('نظام Rebirth — الخادم', 'ServerScriptService')}
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
${ds ? '\n' + dataStoreBlock('RebirthData_v1') : ''}
local BASE_COST = ${num(v.baseCost, 1000)}
local COST_MULTIPLIER = ${num(v.costMultiplier, 2)}
local REWARD_MULTIPLIER = ${num(v.rewardMultiplier, 0.5)}
local REQUEST_COOLDOWN = 1

local rebirthEvent = Instance.new("RemoteFunction")
rebirthEvent.Name = "RebirthRequest"
rebirthEvent.Parent = ReplicatedStorage

local lastRequest = {}

local function getCost(rebirths)
	return math.floor(BASE_COST * COST_MULTIPLIER ^ rebirths)
end

local function updateMultiplier(player, rebirths)
	player:SetAttribute("Multiplier", 1 + rebirths * REWARD_MULTIPLIER)
	player:SetAttribute("NextRebirthCost", getCost(rebirths))
end

Players.PlayerAdded:Connect(function(player)
	local leaderstats = player:FindFirstChild("leaderstats")
	if not leaderstats then
		leaderstats = Instance.new("Folder")
		leaderstats.Name = "leaderstats"
		leaderstats.Parent = player
	end

	local currency = leaderstats:FindFirstChild("${currency}")
	if not currency then
		currency = Instance.new("IntValue")
		currency.Name = "${currency}"
		currency.Parent = leaderstats
	end
${ds ? '\n	local saved = loadData(player) or {}\n	currency.Value = saved.' + currency + ' or currency.Value\n' : ''}
	local rebirths = Instance.new("IntValue")
	rebirths.Name = "Rebirths"
	rebirths.Value = ${ds ? 'saved.Rebirths or 0' : '0'}
	rebirths.Parent = leaderstats

	updateMultiplier(player, rebirths.Value)
end)

rebirthEvent.OnServerInvoke = function(player)
	local now = os.clock()
	if lastRequest[player] and now - lastRequest[player] < REQUEST_COOLDOWN then
		return false, "انتظر قليلاً"
	end
	lastRequest[player] = now

	local leaderstats = player:FindFirstChild("leaderstats")
	if not leaderstats then return false, "لا توجد بيانات" end

	local currency = leaderstats:FindFirstChild("${currency}")
	local rebirths = leaderstats:FindFirstChild("Rebirths")
	local cost = getCost(rebirths.Value)

	if currency.Value < cost then
		return false, "تحتاج " .. (cost - currency.Value) .. " ${currency} إضافية"
	end

	${reset ? 'currency.Value = 0' : 'currency.Value -= cost'}
	rebirths.Value += 1
	updateMultiplier(player, rebirths.Value)

	return true, "تمت إعادة الولادة! المضاعف الآن x" .. player:GetAttribute("Multiplier")
end
${
  ds
    ? `
local function savePlayer(player)
	local leaderstats = player:FindFirstChild("leaderstats")
	if not leaderstats then return end
	saveData(player, {
		${currency} = leaderstats.${currency}.Value,
		Rebirths = leaderstats.Rebirths.Value,
	})
end

game:BindToClose(function()
	for _, player in ipairs(Players:GetPlayers()) do
		savePlayer(player)
	end
end)
`
    : ''
}
Players.PlayerRemoving:Connect(function(player)
	lastRequest[player] = nil${ds ? '\n	savePlayer(player)' : ''}
end)
`

      const client = `${header('نظام Rebirth — زر الواجهة', 'StarterGui › ScreenGui › TextButton')}
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local button = script.Parent
local rebirthRequest = ReplicatedStorage:WaitForChild("RebirthRequest")

local function refreshText()
	local cost = player:GetAttribute("NextRebirthCost") or 0
	button.Text = "Rebirth (" .. cost .. " ${currency})"
end

player:GetAttributeChangedSignal("NextRebirthCost"):Connect(refreshText)
refreshText()

local busy = false
button.MouseButton1Click:Connect(function()
	if busy then return end
	busy = true

	local success, message = rebirthRequest:InvokeServer()
	button.Text = message
	button.BackgroundColor3 = success and Color3.fromRGB(34, 211, 238) or Color3.fromRGB(239, 68, 68)

	task.wait(1.5)
	button.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
	refreshText()
	busy = false
end)
`
      return [
        { name: 'RebirthServer', location: 'ServerScriptService', scriptType: 'Script', code: server.replace(/\n{3,}/g, '\n\n') },
        { name: 'RebirthButton', location: 'StarterGui › ScreenGui › TextButton', scriptType: 'LocalScript', code: client },
      ]
    },
  },
  {
    id: 'killbrick',
    name: 'Kill Bricks',
    description: 'أجزاء ضارة/قاتلة تعمل عبر Tags لكل الخريطة',
    fields: [
      { id: 'tag', label: 'اسم الـ Tag', type: 'text', default: 'KillBrick' },
      { id: 'instantKill', label: 'قتل فوري', type: 'boolean', default: true },
      { id: 'damage', label: 'مقدار الضرر (إن لم يكن فورياً)', type: 'number', default: 25, min: 1 },
      { id: 'cooldown', label: 'فترة التهدئة (ثانية)', type: 'number', default: 0.5, min: 0.1, step: 0.1 },
      { id: 'glow', label: 'تأثير توهج نيون', type: 'boolean', default: true },
    ],
    setup: [
      'حدد الأجزاء المطلوبة واضغط View › Tags ثم أضف Tag بالاسم الذي اخترته.',
      'ضع السكربت في ServerScriptService.',
      'أي Part جديد بنفس الـ Tag سيعمل تلقائياً حتى أثناء اللعب.',
    ],
    build: (v) => {
      const tag = ident(v.tag, 'KillBrick')
      const instant = Boolean(v.instantKill)
      const code = `${header('نظام Kill Bricks', 'ServerScriptService')}
local CollectionService = game:GetService("CollectionService")

local TAG = "${tag}"
local DAMAGE = ${num(v.damage, 25)}
local COOLDOWN = ${num(v.cooldown, 0.5)}

local lastHit = {}

local function onTouched(hit)
	local character = hit.Parent
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.Health <= 0 then return end

	local now = os.clock()
	if lastHit[humanoid] and now - lastHit[humanoid] < COOLDOWN then return end
	lastHit[humanoid] = now

	${instant ? 'humanoid.Health = 0' : 'humanoid:TakeDamage(DAMAGE)'}
end

local function setup(part)
	if not part:IsA("BasePart") then return end
${Boolean(v.glow) ? '	part.Material = Enum.Material.Neon\n	part.Color = Color3.fromRGB(255, 60, 60)\n' : ''}	part.Touched:Connect(onTouched)
end

for _, part in ipairs(CollectionService:GetTagged(TAG)) do
	setup(part)
end

CollectionService:GetInstanceAddedSignal(TAG):Connect(setup)
`
      return [{ name: 'KillBricks', location: 'ServerScriptService', scriptType: 'Script', code }]
    },
  },
  {
    id: 'daily',
    name: 'Daily Reward',
    description: 'مكافأة يومية تُمنح تلقائياً عند الدخول',
    fields: [
      { id: 'currency', label: 'اسم العملة', type: 'text', default: 'Coins' },
      { id: 'reward', label: 'قيمة المكافأة', type: 'number', default: 100, min: 1 },
      { id: 'hours', label: 'كل (ساعة)', type: 'number', default: 24, min: 1 },
      { id: 'streak', label: 'مكافأة السلسلة المتتالية', type: 'boolean', default: true },
    ],
    setup: [
      'تأكد من وجود سكربت Leaderstats بنفس اسم العملة (يمكنك توليده من هنا).',
      'فعّل Enable Studio Access to API Services من إعدادات اللعبة.',
      'ضع السكربت في ServerScriptService.',
    ],
    build: (v) => {
      const currency = ident(v.currency, 'Coins')
      const streak = Boolean(v.streak)
      const code = `${header('نظام المكافأة اليومية', 'ServerScriptService')}
local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")

local rewardStore = DataStoreService:GetDataStore("DailyReward_v1")
local REWARD = ${num(v.reward, 100)}
local COOLDOWN = ${num(v.hours, 24)} * 60 * 60

local function notify(player, text)
	local gui = Instance.new("ScreenGui")
	gui.Name = "DailyRewardNotice"
	gui.ResetOnSpawn = false

	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromOffset(360, 56)
	label.Position = UDim2.new(0.5, -180, 0, 40)
	label.BackgroundColor3 = Color3.fromRGB(18, 18, 18)
	label.TextColor3 = Color3.fromRGB(34, 211, 238)
	label.Font = Enum.Font.GothamBold
	label.TextSize = 20
	label.Text = text
	label.Parent = gui

	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 12)
	corner.Parent = label

	gui.Parent = player:WaitForChild("PlayerGui")
	task.delay(4, function()
		gui:Destroy()
	end)
end

Players.PlayerAdded:Connect(function(player)
	local leaderstats = player:WaitForChild("leaderstats", 15)
	local currency = leaderstats and leaderstats:WaitForChild("${currency}", 5)
	if not currency then
		warn("لم يتم العثور على ${currency} — تأكد من وجود سكربت Leaderstats")
		return
	end

	local key = "Player_" .. player.UserId
	local now = os.time()
	local amount = 0
	local streakCount = 0

	local ok, err = pcall(function()
		rewardStore:UpdateAsync(key, function(old)
			old = old or { lastClaim = 0, streak = 0 }
			local elapsed = now - old.lastClaim
			if elapsed < COOLDOWN then
				return nil
			end
${
  streak
    ? `			old.streak = if elapsed < COOLDOWN * 2 then old.streak + 1 else 1
			streakCount = old.streak
			amount = REWARD * math.min(old.streak, 7)`
    : `			amount = REWARD`
}
			old.lastClaim = now
			return old
		end)
	end)

	if not ok then
		warn("خطأ في المكافأة اليومية: " .. tostring(err))
		return
	end

	if amount > 0 then
		currency.Value += amount
		notify(player, "مكافأتك اليومية: +" .. amount .. " ${currency}"${streak ? ' .. " (سلسلة " .. streakCount .. " أيام)"' : ''})
	end
end)
`
      return [{ name: 'DailyReward', location: 'ServerScriptService', scriptType: 'Script', code }]
    },
  },
]

export function defaultValues(template: ScriptTemplate) {
  return Object.fromEntries(template.fields.map((f) => [f.id, f.default])) as Record<string, string | number | boolean>
}
