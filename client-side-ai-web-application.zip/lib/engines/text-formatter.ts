import type { Block, CodeLang, Engine } from '../types'

const TASHKEEL = /[\u064B-\u0652\u0670\u0640]/g

function words(text: string) {
  return text
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .split(/[^\p{L}\p{N}]+/u)
    .filter(Boolean)
}

function stats(text: string): Block {
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0
  const arabicChars = (text.match(/[\u0600-\u06FF]/g) ?? []).length
  const latinChars = (text.match(/[A-Za-z]/g) ?? []).length
  const sentences = text.split(/[.!?؟。\n]+/).filter((s) => s.trim()).length
  return {
    kind: 'list',
    items: [
      `عدد الكلمات: ${wordCount}`,
      `عدد الأحرف: ${text.length} (بدون مسافات: ${text.replace(/\s/g, '').length})`,
      `أحرف عربية: ${arabicChars} · أحرف لاتينية: ${latinChars}`,
      `عدد الجمل: ${sentences} · عدد الأسطر: ${text.split('\n').length}`,
      `وقت القراءة التقريبي: ${Math.max(1, Math.ceil(wordCount / 200))} دقيقة`,
    ],
  }
}

type Transform = { title: string; lang?: CodeLang; fn: (t: string) => string }

const TRANSFORMS: Record<string, Transform> = {
  clean: {
    title: 'تنظيف النص',
    fn: (t) =>
      t
        .replace(/\r\n/g, '\n')
        .replace(/[ \t]+/g, ' ')
        .replace(/ *\n */g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .replace(/\s+([،,.!?؟:;])/g, '$1')
        .trim(),
  },
  tashkeel: { title: 'إزالة التشكيل', fn: (t) => t.replace(TASHKEEL, '') },
  upper: { title: 'أحرف كبيرة (UPPERCASE)', fn: (t) => t.toUpperCase() },
  lower: { title: 'أحرف صغيرة (lowercase)', fn: (t) => t.toLowerCase() },
  title: {
    title: 'أول حرف كبير (Title Case)',
    fn: (t) => t.toLowerCase().replace(/\b\p{L}/gu, (c) => c.toUpperCase()),
  },
  camel: {
    title: 'camelCase',
    lang: 'javascript',
    fn: (t) =>
      t
        .split('\n')
        .map((line) => words(line).map((w, i) => (i === 0 ? w.toLowerCase() : w[0].toUpperCase() + w.slice(1).toLowerCase())).join(''))
        .join('\n'),
  },
  snake: {
    title: 'snake_case',
    lang: 'python',
    fn: (t) => t.split('\n').map((l) => words(l).map((w) => w.toLowerCase()).join('_')).join('\n'),
  },
  kebab: {
    title: 'kebab-case',
    lang: 'css',
    fn: (t) => t.split('\n').map((l) => words(l).map((w) => w.toLowerCase()).join('-')).join('\n'),
  },
  bullets: {
    title: 'قائمة نقطية',
    fn: (t) =>
      t
        .split(/\n|(?<=[.!?؟])\s+/)
        .map((l) => l.trim())
        .filter(Boolean)
        .map((l) => `• ${l}`)
        .join('\n'),
  },
  numbered: {
    title: 'قائمة مرقمة',
    fn: (t) =>
      t
        .split(/\n|(?<=[.!?؟])\s+/)
        .map((l) => l.trim())
        .filter(Boolean)
        .map((l, i) => `${i + 1}. ${l}`)
        .join('\n'),
  },
  sort: {
    title: 'ترتيب الأسطر أبجدياً',
    fn: (t) => t.split('\n').filter((l) => l.trim()).sort((a, b) => a.localeCompare(b, 'ar')).join('\n'),
  },
  dedupe: {
    title: 'حذف الأسطر المكررة',
    fn: (t) => Array.from(new Set(t.split('\n').map((l) => l.trim()).filter(Boolean))).join('\n'),
  },
  reverse: { title: 'عكس ترتيب الأسطر', fn: (t) => t.split('\n').reverse().join('\n') },
  slug: {
    title: 'رابط صديق (Slug)',
    fn: (t) =>
      t
        .trim()
        .toLowerCase()
        .replace(TASHKEEL, '')
        .replace(/[^\p{L}\p{N}\s-]/gu, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-'),
  },
}

function extract(text: string): Block[] {
  const emails = Array.from(new Set(text.match(/[^\s@]+@[^\s@]+\.[^\s@،,]{2,}/g) ?? []))
  const links = Array.from(new Set(text.match(/https?:\/\/[^\s،,]+/g) ?? []))
  const numbers = Array.from(new Set(text.match(/\d+(?:[.,]\d+)?/g) ?? []))
  const hashtags = Array.from(new Set(text.match(/#[\p{L}\p{N}_]+/gu) ?? []))
  const blocks: Block[] = [{ kind: 'heading', content: 'البيانات المستخرجة' }]
  const add = (label: string, items: string[]) => {
    blocks.push({ kind: 'text', content: `${label} (${items.length})` })
    blocks.push(items.length ? { kind: 'code', lang: 'text', content: items.join('\n') } : { kind: 'note', tone: 'info', content: 'لا يوجد' })
  }
  add('البريد الإلكتروني', emails)
  add('الروابط', links)
  add('الأرقام', numbers)
  add('الوسوم', hashtags)
  return blocks
}

export const textFormatterEngine: Engine = {
  id: 'formatter',
  name: 'منسّق النصوص',
  tagline: 'تنظيف · تحويل · استخراج · تنسيق JSON',
  placeholder: 'الصق النص أو JSON هنا ثم اختر نوع التنسيق…',
  suggestions: [
    '{"name":"لاعب","coins":150,"items":["سيف","درع"],"vip":true}',
    'هَذَا نَصٌّ عَرَبِيٌّ مُشَكَّلٌ بِالكَامِلِ',
    'تواصل معنا على info@example.com أو زر https://example.com #برمجة',
    'player   coins     total    rebirth   count',
  ],
  options: [
    {
      id: 'mode',
      label: 'التنسيق',
      choices: [
        { value: 'auto', label: 'تلقائي' },
        { value: 'clean', label: 'تنظيف' },
        { value: 'tashkeel', label: 'إزالة التشكيل' },
        { value: 'json', label: 'JSON' },
        { value: 'extract', label: 'استخراج' },
        { value: 'bullets', label: 'نقاط' },
        { value: 'numbered', label: 'ترقيم' },
        { value: 'camel', label: 'camelCase' },
        { value: 'snake', label: 'snake_case' },
        { value: 'kebab', label: 'kebab-case' },
        { value: 'upper', label: 'UPPER' },
        { value: 'lower', label: 'lower' },
        { value: 'title', label: 'Title' },
        { value: 'sort', label: 'ترتيب' },
        { value: 'dedupe', label: 'حذف المكرر' },
        { value: 'reverse', label: 'عكس' },
        { value: 'slug', label: 'Slug' },
        { value: 'stats', label: 'إحصائيات' },
      ],
    },
  ],
  run(input, options) {
    let mode = options.mode ?? 'auto'

    if (mode === 'auto') {
      const trimmed = input.trim()
      if (/^[[{]/.test(trimmed)) mode = 'json'
      else if (TASHKEEL.test(trimmed)) mode = 'tashkeel'
      else if (/@|https?:\/\//.test(trimmed)) mode = 'extract'
      else mode = 'clean'
      TASHKEEL.lastIndex = 0
    }

    if (mode === 'json') {
      try {
        const parsed = JSON.parse(input)
        const pretty = JSON.stringify(parsed, null, 2)
        const keys = typeof parsed === 'object' && parsed ? Object.keys(parsed).length : 0
        return {
          blocks: [
            { kind: 'heading', content: 'تنسيق JSON' },
            { kind: 'note', tone: 'success', content: `JSON صالح · ${Array.isArray(parsed) ? `مصفوفة بها ${parsed.length} عنصر` : `${keys} مفتاح في المستوى الأول`}` },
            { kind: 'code', lang: 'json', content: pretty, title: 'formatted.json' },
            { kind: 'text', content: 'النسخة المضغوطة (Minified):' },
            { kind: 'code', lang: 'json', content: JSON.stringify(parsed), title: 'minified.json' },
          ],
        }
      } catch (error) {
        return {
          blocks: [
            { kind: 'heading', content: 'تنسيق JSON' },
            { kind: 'note', tone: 'warn', content: `JSON غير صالح: ${(error as Error).message}` },
            { kind: 'text', content: 'تأكد من استخدام علامات تنصيص مزدوجة للمفاتيح وعدم وجود فواصل زائدة في النهاية.' },
          ],
        }
      }
    }

    if (mode === 'extract') return { blocks: extract(input) }

    if (mode === 'stats') {
      return { blocks: [{ kind: 'heading', content: 'إحصائيات النص' }, stats(input)] }
    }

    const transform = TRANSFORMS[mode] ?? TRANSFORMS.clean
    const output = transform.fn(input)
    return {
      blocks: [
        { kind: 'heading', content: transform.title },
        { kind: 'code', lang: transform.lang ?? 'text', content: output, title: 'النتيجة' },
        { kind: 'text', content: 'إحصائيات النص الناتج:' },
        stats(output),
      ],
    }
  },
}
