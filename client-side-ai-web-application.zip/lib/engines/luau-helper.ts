import type { Block, Engine } from '../types'

type LuauIntent = {
  id: string
  title: string
  match: RegExp
  location: string
  scriptType: 'Script' | 'LocalScript'
  explain: string
  code: (n: number | null) => string
}

const INTENTS: LuauIntent[] = [
  {
    id: 'killbrick',
    title: 'جزء قاتل (Kill Brick)',
    match: /قاتل|يقتل|kill|lava|حمم|لافا/i,
    location: 'داخل الـ Part نفسه',
    scriptType: 'Script',
    explain: 'عند لمس اللاعب للجزء يتم تصفير صحته فوراً، مع حماية من التكرار.',
    code: () => `local part = script.Parent

part.Touched:Connect(function(hit)
	local humanoid = hit.Parent:FindFirstChildOfClass("Humanoid")
	if humanoid and humanoid.Health > 0 then
		humanoid.Health = 0
	end
end)`,
  },
  {
    id: 'teleport',
    title: 'نظام انتقال (Teleport Pad)',
    match: /انتقال|نقل|تنقل|teleport|tp\b|بوابة|portal/i,
    location: 'داخل الـ Part الأول (المنصة)، مع وجود Part اسمه Destination في Workspace',
    scriptType: 'Script',
    explain: 'ينقل اللاعب إلى جزء الوجهة مع فترة تهدئة تمنع النقل المتكرر.',
    code: (n) => `local pad = script.Parent
local destination = workspace:WaitForChild("Destination")
local COOLDOWN = ${n ?? 2}
local recentlyTeleported = {}

pad.Touched:Connect(function(hit)
	local character = hit.Parent
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid or recentlyTeleported[character] then
		return
	end

	recentlyTeleported[character] = true
	character:PivotTo(destination.CFrame + Vector3.new(0, 4, 0))

	task.delay(COOLDOWN, function()
		recentlyTeleported[character] = nil
	end)
end)`,
  },
  {
    id: 'door',
    title: 'باب يفتح بالضغط (ProximityPrompt)',
    match: /باب|door|بوابه|فتح/i,
    location: 'داخل الـ Part الخاص بالباب',
    scriptType: 'Script',
    explain: 'يستخدم ProximityPrompt و TweenService لفتح الباب وإغلاقه بحركة سلسة.',
    code: (n) => `local TweenService = game:GetService("TweenService")

local door = script.Parent
local closedCFrame = door.CFrame
local openCFrame = closedCFrame * CFrame.new(0, door.Size.Y + 0.5, 0)
local tweenInfo = TweenInfo.new(${n ?? 0.6}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

local prompt = Instance.new("ProximityPrompt")
prompt.ActionText = "فتح"
prompt.ObjectText = "باب"
prompt.HoldDuration = 0.2
prompt.Parent = door

local isOpen = false

prompt.Triggered:Connect(function()
	isOpen = not isOpen
	prompt.ActionText = isOpen and "إغلاق" or "فتح"
	TweenService:Create(door, tweenInfo, {
		CFrame = isOpen and openCFrame or closedCFrame,
	}):Play()
end)`,
  },
  {
    id: 'sprint',
    title: 'نظام الركض السريع (Sprint)',
    match: /ركض|جري|سرعة|سرعه|sprint|run|shift/i,
    location: 'StarterPlayer › StarterCharacterScripts',
    scriptType: 'LocalScript',
    explain: 'يزيد سرعة اللاعب عند الضغط على Shift ويعيدها عند الإفلات.',
    code: (n) => `local UserInputService = game:GetService("UserInputService")

local humanoid = script.Parent:WaitForChild("Humanoid")
local WALK_SPEED = 16
local SPRINT_SPEED = ${n ?? 28}

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then return end
	if input.KeyCode == Enum.KeyCode.LeftShift then
		humanoid.WalkSpeed = SPRINT_SPEED
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.KeyCode == Enum.KeyCode.LeftShift then
		humanoid.WalkSpeed = WALK_SPEED
	end
end)`,
  },
  {
    id: 'doublejump',
    title: 'القفز المزدوج (Double Jump)',
    match: /قفز|نط|jump/i,
    location: 'StarterPlayer › StarterCharacterScripts',
    scriptType: 'LocalScript',
    explain: 'يسمح للاعب بالقفز مرة إضافية في الهواء.',
    code: (n) => `local UserInputService = game:GetService("UserInputService")

local character = script.Parent
local humanoid = character:WaitForChild("Humanoid")
local MAX_JUMPS = ${n ?? 2}
local jumps = 0

humanoid.StateChanged:Connect(function(_, newState)
	if newState == Enum.HumanoidStateType.Landed then
		jumps = 0
	elseif newState == Enum.HumanoidStateType.Jumping then
		jumps += 1
	end
end)

UserInputService.JumpRequest:Connect(function()
	local state = humanoid:GetState()
	if state == Enum.HumanoidStateType.Freefall and jumps < MAX_JUMPS then
		humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
	end
end)`,
  },
  {
    id: 'tween',
    title: 'جزء متحرك ودوار (Tween)',
    match: /تحريك|حركة|حركه|دوران|يدور|tween|spin|rotate|متحرك/i,
    location: 'داخل الـ Part المراد تحريكه (Anchored)',
    scriptType: 'Script',
    explain: 'يحرك الجزء صعوداً ونزولاً بشكل لا نهائي مع دوران مستمر.',
    code: (n) => `local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")

local part = script.Parent
part.Anchored = true

local floatTween = TweenService:Create(
	part,
	TweenInfo.new(${n ?? 1.5}, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
	{ Position = part.Position + Vector3.new(0, 3, 0) }
)
floatTween:Play()

local ROTATION_SPEED = math.rad(90)
RunService.Heartbeat:Connect(function(dt)
	part.CFrame *= CFrame.Angles(0, ROTATION_SPEED * dt, 0)
end)`,
  },
  {
    id: 'gui',
    title: 'زر واجهة GUI مع إشعار',
    match: /gui|واجهة|واجهه|زر|button|شاشة|ui\b/i,
    location: 'StarterGui › ScreenGui',
    scriptType: 'LocalScript',
    explain: 'ينشئ زراً بالكامل عبر الكود ويعرض إشعاراً عند الضغط عليه.',
    code: () => `local StarterGui = game:GetService("StarterGui")

local screenGui = script.Parent

local button = Instance.new("TextButton")
button.Name = "ActionButton"
button.Size = UDim2.fromOffset(200, 50)
button.Position = UDim2.new(0.5, -100, 0.85, 0)
button.BackgroundColor3 = Color3.fromRGB(34, 211, 238)
button.TextColor3 = Color3.fromRGB(10, 10, 10)
button.Font = Enum.Font.GothamBold
button.TextSize = 20
button.Text = "اضغط هنا"

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 12)
corner.Parent = button

button.Parent = screenGui

button.MouseButton1Click:Connect(function()
	StarterGui:SetCore("SendNotification", {
		Title = "تم!",
		Text = "لقد ضغطت على الزر بنجاح",
		Duration = 3,
	})
end)`,
  },
  {
    id: 'daynight',
    title: 'دورة الليل والنهار',
    match: /ليل|نهار|وقت|day|night|lighting|إضاءة|اضاءة/i,
    location: 'ServerScriptService',
    scriptType: 'Script',
    explain: 'يغير وقت اللعبة تدريجياً لمحاكاة دورة يوم كاملة.',
    code: (n) => `local Lighting = game:GetService("Lighting")

local MINUTES_PER_DAY = ${n ?? 10}
local hoursPerSecond = 24 / (MINUTES_PER_DAY * 60)

while true do
	local dt = task.wait(0.1)
	Lighting.ClockTime = (Lighting.ClockTime + hoursPerSecond * dt) % 24
end`,
  },
  {
    id: 'coin',
    title: 'عملة قابلة للجمع',
    match: /عملة|عمله|جمع|coin|collect|نقود|فلوس/i,
    location: 'داخل الـ Part الخاص بالعملة',
    scriptType: 'Script',
    explain: 'يضيف قيمة إلى leaderstats عند جمع العملة، ثم يخفيها ويعيد ظهورها بعد مدة.',
    code: (n) => `local Players = game:GetService("Players")

local coin = script.Parent
local VALUE = ${n ?? 10}
local RESPAWN_TIME = 5
local collected = false

coin.Touched:Connect(function(hit)
	if collected then return end
	local player = Players:GetPlayerFromCharacter(hit.Parent)
	if not player then return end

	local leaderstats = player:FindFirstChild("leaderstats")
	local coins = leaderstats and leaderstats:FindFirstChild("Coins")
	if not coins then return end

	collected = true
	coins.Value += VALUE
	coin.Transparency = 1
	coin.CanTouch = false

	task.wait(RESPAWN_TIME)
	coin.Transparency = 0
	coin.CanTouch = true
	collected = false
end)`,
  },
  {
    id: 'admin',
    title: 'أوامر إدارية في الشات',
    match: /أوامر|اوامر|ادمن|أدمن|admin|command|شات|chat/i,
    location: 'ServerScriptService',
    scriptType: 'Script',
    explain: 'يتيح لقائمة محددة من المشرفين تنفيذ أوامر مثل :speed و :kill عبر الشات.',
    code: () => `local Players = game:GetService("Players")

local ADMINS = {
	[game.CreatorId] = true,
}

local commands = {}

commands.speed = function(player, value)
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid.WalkSpeed = tonumber(value) or 16
	end
end

commands.kill = function(player)
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid.Health = 0
	end
end

commands.respawn = function(player)
	player:LoadCharacter()
end

Players.PlayerAdded:Connect(function(player)
	if not ADMINS[player.UserId] then return end

	player.Chatted:Connect(function(message)
		local args = string.split(message, " ")
		local name = string.lower(args[1] or "")
		if string.sub(name, 1, 1) ~= ":" then return end

		local command = commands[string.sub(name, 2)]
		if command then
			command(player, args[2])
		end
	end)
end)`,
  },
]

const ISSUE_RULES: { test: RegExp; message: string; fix?: (code: string) => string }[] = [
  {
    test: /(^|[^.\w])wait\s*\(/m,
    message: 'استخدام wait() قديم وغير دقيق — استبدله بـ task.wait()',
    fix: (c) => c.replace(/(^|[^.\w])wait\s*\(/gm, '$1task.wait('),
  },
  {
    test: /(^|[^.\w])spawn\s*\(/m,
    message: 'spawn() مهمل — استخدم task.spawn()',
    fix: (c) => c.replace(/(^|[^.\w])spawn\s*\(/gm, '$1task.spawn('),
  },
  {
    test: /(^|[^.\w])delay\s*\(/m,
    message: 'delay() مهمل — استخدم task.delay()',
    fix: (c) => c.replace(/(^|[^.\w])delay\s*\(/gm, '$1task.delay('),
  },
  {
    test: /:connect\s*\(/,
    message: ':connect بحرف صغير مهمل — استخدم :Connect',
    fix: (c) => c.replace(/:connect\s*\(/g, ':Connect('),
  },
  {
    test: /game\.(Players|ReplicatedStorage|ServerStorage|TweenService|RunService|UserInputService|DataStoreService|Lighting)\b/,
    message: 'الوصول المباشر للخدمات (game.Players) — يفضّل استخدام game:GetService("Players")',
    fix: (c) => c.replace(/game\.(Players|ReplicatedStorage|ServerStorage|TweenService|RunService|UserInputService|DataStoreService|Lighting)\b/g, 'game:GetService("$1")'),
  },
  {
    test: /Instance\.new\(\s*"[^"]+"\s*,/,
    message: 'تمرير Parent كوسيط ثاني في Instance.new يضر بالأداء — عيّن Parent في النهاية',
  },
  {
    test: /\bWorkspace\b/,
    message: 'استخدم workspace (بحرف صغير) بدلاً من Workspace',
    fix: (c) => c.replace(/\bWorkspace\b/g, 'workspace'),
  },
  {
    test: /while\s+true\s+do(?![\s\S]*?(task\.wait|wait)\s*\()/,
    message: 'حلقة while true بدون انتظار ستجمّد اللعبة — أضف task.wait() داخلها',
  },
  {
    test: /:GetAsync\(|:SetAsync\(/,
    message: 'تأكد من تغليف استدعاءات DataStore داخل pcall لتجنب الأعطال',
  },
]

function looksLikeCode(input: string) {
  return /\b(local|function|end|game[:.]|script\.Parent|Instance\.new)\b/.test(input) && input.includes('\n')
}

function reviewCode(input: string): Block[] {
  const issues = ISSUE_RULES.filter((r) => r.test.test(input))
  let fixed = input
  for (const rule of issues) if (rule.fix) fixed = rule.fix(fixed)

  const lines = input.split('\n').length
  const functions = (input.match(/\bfunction\b/g) ?? []).length
  const connections = (input.match(/:Connect\(/gi) ?? []).length
  const services = Array.from(new Set(Array.from(input.matchAll(/GetService\("(\w+)"\)|game\.(\w+Service|Players)/g), (m) => m[1] ?? m[2])))

  const blocks: Block[] = [
    { kind: 'heading', content: 'مراجعة سكربت Luau' },
    {
      kind: 'list',
      items: [
        `عدد الأسطر: ${lines}`,
        `عدد الدوال: ${functions}`,
        `عدد الأحداث المتصلة (Connections): ${connections}`,
        `الخدمات المستخدمة: ${services.length ? services.join('، ') : 'لا يوجد'}`,
      ],
    },
  ]

  if (issues.length === 0) {
    blocks.push({ kind: 'note', tone: 'success', content: 'ممتاز! لم يتم العثور على أنماط مهملة أو مشاكل شائعة في السكربت.' })
    return blocks
  }

  blocks.push({ kind: 'note', tone: 'warn', content: `تم العثور على ${issues.length} ملاحظة تحتاج إلى تحسين:` })
  blocks.push({ kind: 'list', ordered: true, items: issues.map((i) => i.message) })
  if (fixed !== input) {
    blocks.push({ kind: 'text', content: 'إليك النسخة المحسّنة بعد تطبيق الإصلاحات التلقائية:' })
    blocks.push({ kind: 'code', lang: 'luau', content: fixed, title: 'Fixed.server.lua' })
  }
  return blocks
}

export const luauHelperEngine: Engine = {
  id: 'luau',
  name: 'مساعد Luau',
  tagline: 'سكربتات روبلوكس + مراجعة وإصلاح الأكواد',
  placeholder: 'اطلب سكربت (مثال: باب يفتح بالضغط) أو الصق كود Luau لمراجعته…',
  suggestions: [
    'سكربت باب يفتح بالضغط',
    'نظام ركض بسرعة 30',
    'جزء قاتل مثل الحمم',
    'أوامر أدمن في الشات',
    'دورة ليل ونهار',
  ],
  options: [
    {
      id: 'mode',
      label: 'الوضع',
      choices: [
        { value: 'auto', label: 'تلقائي' },
        { value: 'generate', label: 'توليد سكربت' },
        { value: 'review', label: 'مراجعة كود' },
      ],
    },
  ],
  run(input, options) {
    const mode = options.mode ?? 'auto'
    if (mode === 'review' || (mode === 'auto' && looksLikeCode(input))) {
      return { blocks: reviewCode(input) }
    }

    const intent = INTENTS.find((i) => i.match.test(input))
    const numberMatch = input.match(/\d+(?:\.\d+)?/)
    const n = numberMatch ? Number(numberMatch[0]) : null

    if (!intent) {
      return {
        blocks: [
          { kind: 'heading', content: 'لم أتعرف على نوع السكربت' },
          {
            kind: 'text',
            content: 'يمكنني توليد السكربتات التالية فوراً. اكتب اسم أي منها، ويمكنك إضافة رقم لتخصيص القيمة الأساسية (مثل السرعة أو المدة):',
          },
          { kind: 'list', items: INTENTS.map((i) => i.title) },
          { kind: 'note', tone: 'info', content: 'لأنظمة متقدمة مثل Leaderstats و Rebirth و Checkpoints استخدم تبويب "مولّد السكربتات".' },
        ],
      }
    }

    return {
      blocks: [
        { kind: 'heading', content: intent.title },
        { kind: 'text', content: intent.explain },
        { kind: 'code', lang: 'luau', content: intent.code(n), title: `${intent.scriptType}.lua` },
        {
          kind: 'list',
          ordered: true,
          items: [
            `أنشئ ${intent.scriptType} جديد.`,
            `ضعه في: ${intent.location}.`,
            'الصق الكود واضغط Play للتجربة.',
          ],
        },
        ...(n !== null ? [{ kind: 'note' as const, tone: 'success' as const, content: `تم تخصيص القيمة الأساسية إلى ${n} بناءً على طلبك.` }] : []),
      ],
    }
  },
}
