import type { Engine } from '../types'

type Domain = { id: string; match: RegExp; role: string; expertise: string[]; imageStyle: string }

const DOMAINS: Domain[] = [
  {
    id: 'roblox',
    match: /روبلوكس|roblox|luau|لعبة|لعبه|game|أوبي|obby/i,
    role: 'مطوّر ألعاب Roblox محترف وخبير في لغة Luau',
    expertise: ['أفضل ممارسات Luau الحديثة (task library)', 'أمان العميل/الخادم و RemoteEvents', 'تحسين الأداء وتجربة اللاعب'],
    imageStyle: 'vibrant 3D game render, Roblox style, low-poly, soft global illumination',
  },
  {
    id: 'code',
    match: /كود|برمجة|برمجه|code|تطبيق|موقع|app|api|دالة|react|بايثون|python/i,
    role: 'مهندس برمجيات أول بخبرة 10 سنوات',
    expertise: ['كتابة كود نظيف وقابل للصيانة', 'معالجة الأخطاء والحالات الحدّية', 'شرح الحلول خطوة بخطوة'],
    imageStyle: 'futuristic tech illustration, isometric, neon cyan accents, dark background',
  },
  {
    id: 'marketing',
    match: /تسويق|إعلان|اعلان|منتج|مبيعات|marketing|براند|علامة تجارية|سوشيال|انستقرام/i,
    role: 'خبير تسويق رقمي وكاتب محتوى إعلاني',
    expertise: ['صياغة رسائل مقنعة', 'فهم الجمهور المستهدف', 'دعوات واضحة لاتخاذ إجراء (CTA)'],
    imageStyle: 'premium product photography, studio lighting, clean minimal background',
  },
  {
    id: 'education',
    match: /شرح|تعليم|درس|طالب|اشرح|تعلم|education|learn/i,
    role: 'معلّم خبير يبسّط المفاهيم المعقدة',
    expertise: ['استخدام أمثلة من الحياة اليومية', 'التدرج من البسيط إلى المعقد', 'أسئلة مراجعة قصيرة'],
    imageStyle: 'friendly educational illustration, flat design, clear composition',
  },
  {
    id: 'writing',
    match: /مقال|قصة|قصه|كتابة|كتابه|رواية|شعر|story|article|blog|مدونة/i,
    role: 'كاتب محترف ومحرر أدبي',
    expertise: ['أسلوب سردي جذاب', 'بنية واضحة (مقدمة، عرض، خاتمة)', 'لغة عربية فصيحة وسليمة'],
    imageStyle: 'cinematic digital painting, dramatic lighting, rich atmosphere',
  },
]

const FALLBACK: Domain = {
  id: 'general',
  match: /.*/,
  role: 'مساعد خبير ومتعدد التخصصات',
  expertise: ['الدقة في المعلومات', 'التنظيم والوضوح', 'تقديم أمثلة عملية'],
  imageStyle: 'highly detailed digital art, cinematic composition, dramatic lighting',
}

const TONES: Record<string, string> = {
  professional: 'احترافي ورسمي ودقيق',
  creative: 'إبداعي وملهم وغير تقليدي',
  simple: 'بسيط وودود وسهل الفهم للمبتدئين',
}

export const promptBuilderEngine: Engine = {
  id: 'prompt',
  name: 'باني البرومبتات',
  tagline: 'حوّل فكرتك إلى برومبت احترافي منظّم',
  placeholder: 'اكتب فكرتك ببساطة… مثال: أريد شرح نظام DataStore في روبلوكس للمبتدئين',
  suggestions: [
    'أريد خطة لبناء لعبة أوبي في روبلوكس',
    'اكتب إعلان لمتجر قهوة مختصة',
    'اشرح الذكاء الاصطناعي لطالب في الثانوية',
    'صورة مدينة مستقبلية في الصحراء ليلاً',
  ],
  options: [
    {
      id: 'target',
      label: 'الهدف',
      choices: [
        { value: 'chat', label: 'محادثة نصية' },
        { value: 'code', label: 'برمجة' },
        { value: 'image', label: 'توليد صور' },
      ],
    },
    {
      id: 'tone',
      label: 'الأسلوب',
      choices: [
        { value: 'professional', label: 'احترافي' },
        { value: 'creative', label: 'إبداعي' },
        { value: 'simple', label: 'مبسّط' },
      ],
    },
  ],
  run(input, options) {
    const idea = input.trim().replace(/^(أريد|اريد|ابغى|أبغى|ابي|أبي|اكتب|أكتب)\s+/, '')
    const target = options.target ?? 'chat'
    const tone = TONES[options.tone ?? 'professional']
    const domain = DOMAINS.find((d) => d.match.test(input)) ?? FALLBACK

    if (target === 'image') {
      const prompt = `${idea}, ${domain.imageStyle}, ultra detailed, 8k, sharp focus, volumetric light, ${
        options.tone === 'creative' ? 'surreal, imaginative color palette' : options.tone === 'simple' ? 'clean, simple shapes' : 'photorealistic, professional color grading'
      } --ar 16:9 --style raw`
      return {
        blocks: [
          { kind: 'heading', content: 'برومبت توليد صور' },
          { kind: 'text', content: 'نماذج توليد الصور تفهم الإنجليزية بشكل أفضل، لذا أضفت كلمات أسلوب إنجليزية بجوار وصفك. يُنصح بترجمة الوصف الأساسي للإنجليزية لنتائج أدق.' },
          { kind: 'code', lang: 'text', content: prompt, title: 'Image Prompt' },
          { kind: 'text', content: 'برومبت سلبي (Negative Prompt) مقترح:' },
          { kind: 'code', lang: 'text', content: 'blurry, low quality, distorted, extra limbs, watermark, text, jpeg artifacts', title: 'Negative Prompt' },
        ],
      }
    }

    const outputFormat =
      target === 'code'
        ? ['كود كامل داخل كتلة كود واحدة مع تحديد اللغة', 'شرح مختصر لكل جزء رئيسي', 'طريقة التشغيل أو التركيب', 'تحسينات مقترحة اختيارية']
        : ['عنوان رئيسي واضح', 'نقاط منظمة بعناوين فرعية', 'أمثلة عملية', 'خلاصة في 3 أسطر']

    const prompt = `# الدور
أنت ${domain.role}.

# السياق
${idea}

# المهمة
${target === 'code' ? 'اكتب حلاً برمجياً كاملاً وجاهزاً للاستخدام يحقق المطلوب أعلاه.' : 'قدّم إجابة شاملة ومفصّلة تحقق المطلوب أعلاه.'}

# معايير الجودة
${domain.expertise.map((e) => `- ${e}`).join('\n')}
- الأسلوب: ${tone}

# القيود
- اكتب باللغة العربية${target === 'code' ? ' (والكود والتعليقات البرمجية بالإنجليزية)' : ''}.
- لا تفترض معلومات غير مذكورة؛ اسألني إذا احتجت توضيحاً.
- تجنّب الحشو والتكرار.

# صيغة المخرجات
${outputFormat.map((f, i) => `${i + 1}. ${f}`).join('\n')}`

    return {
      blocks: [
        { kind: 'heading', content: 'برومبت احترافي جاهز' },
        {
          kind: 'list',
          items: [
            `المجال المكتشف: ${domain.role}`,
            `الهدف: ${target === 'code' ? 'برمجة' : 'محادثة نصية'}`,
            `الأسلوب: ${tone}`,
          ],
        },
        { kind: 'code', lang: 'text', content: prompt, title: 'Prompt.md' },
        { kind: 'note', tone: 'info', content: 'انسخ البرومبت والصقه في أي نموذج ذكاء اصطناعي. يمكنك تغيير الهدف والأسلوب من الأعلى لإعادة البناء.' },
      ],
    }
  },
}
