import type { Block, CodeLang, Engine } from '../types'

type LogicLang = 'javascript' | 'typescript' | 'python'
type UiLang = 'html' | 'tsx' | 'css'

type LogicIntent = {
  id: string
  title: string
  match: RegExp
  defaultName: string
  explain: string
  build: (lang: LogicLang, name: string) => string
}

type UiIntent = {
  id: string
  title: string
  match: RegExp
  build: (lang: UiLang, name: string) => string
}

const snake = (s: string) => s.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase()

const LOGIC_INTENTS: LogicIntent[] = [
  {
    id: 'sort',
    title: 'دالة فرز مصفوفة كائنات',
    match: /فرز|ترتيب|sort/i,
    defaultName: 'sortByKey',
    explain: 'تقوم الدالة بإنشاء نسخة جديدة من المصفوفة دون تعديل الأصل، ثم ترتبها حسب المفتاح المحدد تصاعدياً أو تنازلياً.',
    build: (lang, name) => {
      if (lang === 'python')
        return `def ${snake(name)}(items: list[dict], key: str, descending: bool = False) -> list[dict]:
    """فرز قائمة من القواميس حسب مفتاح معين."""
    return sorted(items, key=lambda item: item.get(key), reverse=descending)


users = [
    {"name": "سارة", "age": 28},
    {"name": "أحمد", "age": 34},
    {"name": "ليلى", "age": 21},
]

print(${snake(name)}(users, "age"))
print(${snake(name)}(users, "age", descending=True))`
      const sig =
        lang === 'typescript'
          ? `export function ${name}<T>(items: T[], key: keyof T, order: 'asc' | 'desc' = 'asc'): T[]`
          : `export function ${name}(items, key, order = 'asc')`
      return `${sig} {
  const direction = order === 'asc' ? 1 : -1
  return [...items].sort((a, b) => {
    if (a[key] < b[key]) return -1 * direction
    if (a[key] > b[key]) return 1 * direction
    return 0
  })
}

const users = [
  { name: 'سارة', age: 28 },
  { name: 'أحمد', age: 34 },
  { name: 'ليلى', age: 21 },
]

console.log(${name}(users, 'age'))
console.log(${name}(users, 'age', 'desc'))`
    },
  },
  {
    id: 'fetch',
    title: 'دالة جلب بيانات من API مع معالجة الأخطاء',
    match: /api|fetch|جلب|طلب|ريكوست|request|http/i,
    defaultName: 'fetchJson',
    explain: 'تتضمن الدالة مهلة زمنية (timeout) لإلغاء الطلب، والتحقق من حالة الاستجابة، ورسائل خطأ واضحة.',
    build: (lang, name) => {
      if (lang === 'python')
        return `import json
import urllib.request
from urllib.error import HTTPError, URLError


def ${snake(name)}(url: str, timeout: int = 8) -> dict:
    """جلب بيانات JSON من رابط مع معالجة الأخطاء."""
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as error:
        raise RuntimeError(f"خطأ في الخادم: {error.code}") from error
    except URLError as error:
        raise RuntimeError(f"تعذر الاتصال: {error.reason}") from error


data = ${snake(name)}("https://jsonplaceholder.typicode.com/todos/1")
print(data)`
      const ts = lang === 'typescript'
      return `export async function ${name}${ts ? '<T>' : ''}(url${ts ? ': string' : ''}, timeoutMs${ts ? ': number' : ''} = 8000)${ts ? ': Promise<T>' : ''} {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const response = await fetch(url, { signal: controller.signal })
    if (!response.ok) {
      throw new Error(\`خطأ في الخادم: \${response.status}\`)
    }
    return ${ts ? '(await response.json()) as T' : 'await response.json()'}
  } catch (error) {
    if (${ts ? '(error as Error).name' : 'error.name'} === 'AbortError') {
      throw new Error('انتهت مهلة الطلب')
    }
    throw error
  } finally {
    clearTimeout(timer)
  }
}

${name}('https://jsonplaceholder.typicode.com/todos/1')
  .then((data) => console.log(data))
  .catch((error) => console.error(error.message))`
    },
  },
  {
    id: 'email',
    title: 'دالة التحقق من صحة البريد الإلكتروني',
    match: /بريد|ايميل|إيميل|email|validat/i,
    defaultName: 'isValidEmail',
    explain: 'تستخدم الدالة تعبيراً نمطياً (Regex) عملياً يغطي أغلب صيغ البريد الشائعة، مع إزالة المسافات الزائدة.',
    build: (lang, name) => {
      if (lang === 'python')
        return `import re

EMAIL_PATTERN = re.compile(r"^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$")


def ${snake(name)}(email: str) -> bool:
    """التحقق من صحة صيغة البريد الإلكتروني."""
    return bool(EMAIL_PATTERN.match(email.strip()))


for value in ["user@example.com", "خطأ@", "name@site.io"]:
    print(value, "→", ${snake(name)}(value))`
      const ts = lang === 'typescript'
      return `const EMAIL_PATTERN = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/

export function ${name}(email${ts ? ': string' : ''})${ts ? ': boolean' : ''} {
  return EMAIL_PATTERN.test(email.trim())
}

for (const value of ['user@example.com', 'خطأ@', 'name@site.io']) {
  console.log(value, '→', ${name}(value))
}`
    },
  },
  {
    id: 'password',
    title: 'مولّد كلمات مرور قوية',
    match: /كلمة مرور|كلمات مرور|باسورد|password/i,
    defaultName: 'generatePassword',
    explain: 'يعتمد المولّد على مصدر عشوائي آمن تشفيرياً (crypto / secrets) بدلاً من Math.random.',
    build: (lang, name) => {
      if (lang === 'python')
        return `import secrets
import string


def ${snake(name)}(length: int = 16, symbols: bool = True) -> str:
    """توليد كلمة مرور قوية وآمنة تشفيرياً."""
    alphabet = string.ascii_letters + string.digits
    if symbols:
        alphabet += "!@#$%^&*()-_=+"
    return "".join(secrets.choice(alphabet) for _ in range(length))


print(${snake(name)}())
print(${snake(name)}(24, symbols=False))`
      const ts = lang === 'typescript'
      return `const LETTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
const DIGITS = '0123456789'
const SYMBOLS = '!@#$%^&*()-_=+'

export function ${name}(length${ts ? ': number' : ''} = 16, useSymbols${ts ? ': boolean' : ''} = true)${ts ? ': string' : ''} {
  const alphabet = LETTERS + DIGITS + (useSymbols ? SYMBOLS : '')
  const values = crypto.getRandomValues(new Uint32Array(length))
  return Array.from(values, (v) => alphabet[v % alphabet.length]).join('')
}

console.log(${name}())
console.log(${name}(24, false))`
    },
  },
  {
    id: 'fibonacci',
    title: 'متتالية فيبوناتشي',
    match: /فيبوناتشي|fibonacci|fib/i,
    defaultName: 'fibonacci',
    explain: 'نسخة تكرارية (iterative) سريعة بتعقيد O(n) بدلاً من النسخة العودية البطيئة.',
    build: (lang, name) => {
      if (lang === 'python')
        return `def ${snake(name)}(count: int) -> list[int]:
    """إرجاع أول count عنصر من متتالية فيبوناتشي."""
    sequence = []
    a, b = 0, 1
    for _ in range(count):
        sequence.append(a)
        a, b = b, a + b
    return sequence


print(${snake(name)}(10))`
      const ts = lang === 'typescript'
      return `export function ${name}(count${ts ? ': number' : ''})${ts ? ': number[]' : ''} {
  const sequence${ts ? ': number[]' : ''} = []
  let [a, b] = [0, 1]
  for (let i = 0; i < count; i++) {
    sequence.push(a)
    ;[a, b] = [b, a + b]
  }
  return sequence
}

console.log(${name}(10))`
    },
  },
  {
    id: 'prime',
    title: 'فحص الأعداد الأولية',
    match: /اولي|أولي|prime/i,
    defaultName: 'isPrime',
    explain: 'تفحص الدالة القواسم حتى الجذر التربيعي فقط وتتخطى الأعداد الزوجية لتسريع الأداء.',
    build: (lang, name) => {
      if (lang === 'python')
        return `def ${snake(name)}(n: int) -> bool:
    """التحقق مما إذا كان العدد أولياً."""
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


print([n for n in range(50) if ${snake(name)}(n)])`
      const ts = lang === 'typescript'
      return `export function ${name}(n${ts ? ': number' : ''})${ts ? ': boolean' : ''} {
  if (n < 2) return false
  if (n % 2 === 0) return n === 2
  for (let i = 3; i * i <= n; i += 2) {
    if (n % i === 0) return false
  }
  return true
}

console.log(Array.from({ length: 50 }, (_, i) => i).filter(${name}))`
    },
  },
  {
    id: 'debounce',
    title: 'دالة Debounce لتأخير التنفيذ',
    match: /debounce|تأخير|تاخير|throttle/i,
    defaultName: 'debounce',
    explain: 'تمنع الدالة التنفيذ المتكرر، ولا تستدعي الدالة الأصلية إلا بعد توقف الاستدعاءات لمدة محددة. مثالية لحقول البحث.',
    build: (lang, name) => {
      if (lang === 'python')
        return `import threading
from typing import Callable


def ${snake(name)}(wait: float) -> Callable:
    """مُزخرف يؤخر التنفيذ حتى تتوقف الاستدعاءات لمدة wait ثانية."""
    def decorator(fn: Callable) -> Callable:
        timer = None

        def wrapper(*args, **kwargs):
            nonlocal timer
            if timer:
                timer.cancel()
            timer = threading.Timer(wait, lambda: fn(*args, **kwargs))
            timer.start()

        return wrapper
    return decorator


@${snake(name)}(0.3)
def search(query: str):
    print("البحث عن:", query)


search("ر")
search("روب")
search("روبلوكس")  # سيتم تنفيذ هذا فقط`
      const ts = lang === 'typescript'
      return `export function ${name}${ts ? '<T extends (...args: never[]) => void>' : ''}(fn${ts ? ': T' : ''}, wait${ts ? ': number' : ''} = 300) {
  let timer${ts ? ': ReturnType<typeof setTimeout> | undefined' : ''}
  return (...args${ts ? ': Parameters<T>' : ''}) => {
    clearTimeout(timer)
    timer = setTimeout(() => fn(...args), wait)
  }
}

const search = ${name}((query${ts ? ': string' : ''}) => console.log('البحث عن:', query), 300)

search('ر')
search('روب')
search('روبلوكس') // سيتم تنفيذ هذا فقط`
    },
  },
  {
    id: 'class',
    title: 'فئة (Class) لإدارة عناصر',
    match: /class|كلاس|فئة|كائن|مهام|todo|قائمة/i,
    defaultName: 'TaskManager',
    explain: 'فئة متكاملة تدعم الإضافة والحذف وتبديل الحالة والتصفية، مع معرّفات فريدة لكل عنصر.',
    build: (lang, name) => {
      const cls = name.charAt(0).toUpperCase() + name.slice(1)
      if (lang === 'python')
        return `from dataclasses import dataclass, field
from itertools import count


@dataclass
class Task:
    id: int
    title: str
    done: bool = False


@dataclass
class ${cls}:
    tasks: list[Task] = field(default_factory=list)
    _ids: count = field(default_factory=lambda: count(1), repr=False)

    def add(self, title: str) -> Task:
        task = Task(next(self._ids), title.strip())
        self.tasks.append(task)
        return task

    def toggle(self, task_id: int) -> None:
        for task in self.tasks:
            if task.id == task_id:
                task.done = not task.done

    def remove(self, task_id: int) -> None:
        self.tasks = [t for t in self.tasks if t.id != task_id]

    def pending(self) -> list[Task]:
        return [t for t in self.tasks if not t.done]


manager = ${cls}()
manager.add("تعلم Luau")
manager.add("بناء لعبة أوبي")
manager.toggle(1)
print(manager.pending())`
      const ts = lang === 'typescript'
      return `${ts ? `type Task = { id: number; title: string; done: boolean }\n\n` : ''}export class ${cls} {
  ${ts ? 'private tasks: Task[] = []\n  private nextId = 1' : '#tasks = []\n  #nextId = 1'}

  add(title${ts ? ': string' : ''})${ts ? ': Task' : ''} {
    const task = { id: this.${ts ? 'nextId' : '#nextId'}++, title: title.trim(), done: false }
    this.${ts ? 'tasks' : '#tasks'}.push(task)
    return task
  }

  toggle(id${ts ? ': number' : ''}) {
    const task = this.${ts ? 'tasks' : '#tasks'}.find((t) => t.id === id)
    if (task) task.done = !task.done
  }

  remove(id${ts ? ': number' : ''}) {
    this.${ts ? 'tasks' : '#tasks'} = this.${ts ? 'tasks' : '#tasks'}.filter((t) => t.id !== id)
  }

  get pending() {
    return this.${ts ? 'tasks' : '#tasks'}.filter((t) => !t.done)
  }
}

const manager = new ${cls}()
manager.add('تعلم Luau')
manager.add('بناء لعبة أوبي')
manager.toggle(1)
console.log(manager.pending)`
    },
  },
]

const UI_INTENTS: UiIntent[] = [
  {
    id: 'form',
    title: 'نموذج تسجيل دخول',
    match: /نموذج|فورم|form|تسجيل|login|دخول/i,
    build: (lang, name) => {
      if (lang === 'css')
        return `.login-form {
  display: grid;
  gap: 1rem;
  width: min(100%, 380px);
  padding: 2rem;
  border-radius: 16px;
  background: #121212;
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.login-form label {
  display: grid;
  gap: 0.4rem;
  font-size: 0.9rem;
  color: #a1a1aa;
}

.login-form input {
  padding: 0.75rem 1rem;
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  background: #0a0a0a;
  color: #fafafa;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.login-form input:focus {
  outline: none;
  border-color: #22d3ee;
  box-shadow: 0 0 0 3px rgba(34, 211, 238, 0.25);
}

.login-form button {
  padding: 0.8rem;
  border: 0;
  border-radius: 10px;
  background: #22d3ee;
  color: #04161a;
  font-weight: 600;
  cursor: pointer;
}`
      if (lang === 'tsx')
        return `'use client'

import { useState, type FormEvent } from 'react'

export function ${name}() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  function handleSubmit(event: FormEvent) {
    event.preventDefault()
    if (!email.includes('@')) return setError('البريد الإلكتروني غير صالح')
    if (password.length < 8) return setError('كلمة المرور قصيرة جداً')
    setError('')
    console.log({ email })
  }

  return (
    <form onSubmit={handleSubmit} dir="rtl" className="grid w-full max-w-sm gap-4 rounded-2xl border border-white/10 bg-neutral-900 p-6">
      <h2 className="text-xl font-semibold text-white">تسجيل الدخول</h2>
      <label className="grid gap-1.5 text-sm text-neutral-400">
        البريد الإلكتروني
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-lg border border-white/10 bg-black px-3 py-2 text-white outline-none focus:border-cyan-400" />
      </label>
      <label className="grid gap-1.5 text-sm text-neutral-400">
        كلمة المرور
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="rounded-lg border border-white/10 bg-black px-3 py-2 text-white outline-none focus:border-cyan-400" />
      </label>
      {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
      <button type="submit" className="rounded-lg bg-cyan-400 py-2.5 font-semibold text-black">دخول</button>
    </form>
  )
}`
      return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>تسجيل الدخول</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <form class="login-form" id="${name}">
    <h2>تسجيل الدخول</h2>
    <label>
      البريد الإلكتروني
      <input type="email" name="email" required />
    </label>
    <label>
      كلمة المرور
      <input type="password" name="password" minlength="8" required />
    </label>
    <button type="submit">دخول</button>
  </form>
</body>
</html>`
    },
  },
  {
    id: 'navbar',
    title: 'شريط تنقل متجاوب',
    match: /navbar|شريط|تنقل|قائمة علوية|هيدر|header|nav/i,
    build: (lang, name) => {
      if (lang === 'css')
        return `.navbar {
  position: sticky;
  top: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.5rem;
  background: rgba(10, 10, 10, 0.7);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.navbar ul {
  display: flex;
  gap: 1.5rem;
  list-style: none;
  margin: 0;
  padding: 0;
}

.navbar a {
  color: #a1a1aa;
  text-decoration: none;
  transition: color 0.2s;
}

.navbar a:hover {
  color: #22d3ee;
}

@media (max-width: 640px) {
  .navbar ul {
    display: none;
  }
}`
      if (lang === 'tsx')
        return `'use client'

import { useState } from 'react'

const LINKS = ['الرئيسية', 'الخدمات', 'الأسعار', 'تواصل معنا']

export function ${name}() {
  const [open, setOpen] = useState(false)

  return (
    <header dir="rtl" className="sticky top-0 border-b border-white/10 bg-black/70 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <span className="font-bold text-cyan-400">شعاري</span>
        <ul className="hidden gap-6 md:flex">
          {LINKS.map((link) => (
            <li key={link}><a href="#" className="text-neutral-400 hover:text-cyan-400">{link}</a></li>
          ))}
        </ul>
        <button onClick={() => setOpen(!open)} aria-expanded={open} className="text-white md:hidden">القائمة</button>
      </nav>
      {open && (
        <ul className="grid gap-3 px-6 pb-4 md:hidden">
          {LINKS.map((link) => (
            <li key={link}><a href="#" className="text-neutral-300">{link}</a></li>
          ))}
        </ul>
      )}
    </header>
  )
}`
      return `<header class="navbar" id="${name}">
  <a href="#" class="logo">شعاري</a>
  <nav aria-label="القائمة الرئيسية">
    <ul>
      <li><a href="#">الرئيسية</a></li>
      <li><a href="#">الخدمات</a></li>
      <li><a href="#">الأسعار</a></li>
      <li><a href="#">تواصل معنا</a></li>
    </ul>
  </nav>
</header>`
    },
  },
  {
    id: 'button',
    title: 'زر نيون متحرك',
    match: /زر|button|btn/i,
    build: (lang, name) => {
      if (lang === 'css')
        return `.neon-button {
  padding: 0.85rem 2rem;
  border: 1px solid #22d3ee;
  border-radius: 999px;
  background: transparent;
  color: #22d3ee;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.25s ease;
}

.neon-button:hover {
  background: #22d3ee;
  color: #04161a;
  box-shadow: 0 0 24px rgba(34, 211, 238, 0.6);
}

.neon-button:active {
  transform: scale(0.97);
}`
      if (lang === 'tsx')
        return `type Props = { label: string; onClick?: () => void }

export function ${name}({ label, onClick }: Props) {
  return (
    <button
      onClick={onClick}
      className="rounded-full border border-cyan-400 px-8 py-3 font-semibold text-cyan-400 transition hover:bg-cyan-400 hover:text-black hover:shadow-[0_0_24px_rgba(34,211,238,0.6)] active:scale-95"
    >
      {label}
    </button>
  )
}`
      return `<button class="neon-button" id="${name}" type="button">ابدأ الآن</button>`
    },
  },
  {
    id: 'card',
    title: 'بطاقة عرض زجاجية',
    match: /.*/,
    build: (lang, name) => {
      if (lang === 'css')
        return `.glass-card {
  max-width: 360px;
  padding: 1.75rem;
  border-radius: 20px;
  background: linear-gradient(160deg, rgba(255, 255, 255, 0.06), rgba(255, 255, 255, 0.02));
  backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 255, 255, 0.08);
  color: #ededed;
  transition: transform 0.3s, box-shadow 0.3s;
}

.glass-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 0 32px -8px rgba(34, 211, 238, 0.5);
}

.glass-card h3 {
  margin: 0 0 0.5rem;
  color: #22d3ee;
}`
      if (lang === 'tsx')
        return `type Props = { title: string; description: string }

export function ${name}({ title, description }: Props) {
  return (
    <article dir="rtl" className="max-w-sm rounded-2xl border border-white/10 bg-white/5 p-7 text-neutral-200 backdrop-blur transition hover:-translate-y-1 hover:shadow-[0_0_32px_-8px_rgba(34,211,238,0.5)]">
      <h3 className="mb-2 text-lg font-semibold text-cyan-400">{title}</h3>
      <p className="leading-relaxed text-neutral-400">{description}</p>
    </article>
  )
}`
      return `<article class="glass-card" id="${name}">
  <h3>عنوان البطاقة</h3>
  <p>وصف مختصر وواضح للمحتوى المعروض داخل هذه البطاقة.</p>
</article>`
    },
  },
]

function detectLanguage(prompt: string): CodeLang {
  const p = prompt.toLowerCase()
  if (/react|رياكت|tsx|مكون|كومبوننت|component/.test(p)) return 'tsx'
  if (/\bcss\b|تنسيق css|ستايل|style/.test(p)) return 'css'
  if (/html|صفحة|اتش تي ام ال/.test(p)) return 'html'
  if (/python|بايثون|\bpy\b/.test(p)) return 'python'
  if (/typescript|تايب ?سكربت|\bts\b/.test(p)) return 'typescript'
  return 'javascript'
}

function extractName(prompt: string): string | null {
  const m = prompt.match(/(?:اسم|باسم|اسمها|اسمه|named|called|name)\s*[:=]?\s*([A-Za-z_][A-Za-z0-9_]*)/i)
  return m ? m[1] : null
}

const UI_DEFAULT_NAMES: Record<string, string> = {
  form: 'LoginForm',
  navbar: 'Navbar',
  button: 'NeonButton',
  card: 'GlassCard',
}

export const codeGeneratorEngine: Engine = {
  id: 'code',
  name: 'مولّد الأكواد',
  tagline: 'JavaScript · TypeScript · Python · HTML · React',
  placeholder: 'صف الكود الذي تريده… مثال: دالة بايثون للتحقق من البريد الإلكتروني',
  suggestions: [
    'دالة TypeScript لجلب بيانات من API',
    'مولّد كلمات مرور بلغة بايثون',
    'مكون React لنموذج تسجيل دخول',
    'دالة debounce لحقل البحث',
    'كلاس لإدارة قائمة المهام',
  ],
  options: [
    {
      id: 'lang',
      label: 'اللغة',
      choices: [
        { value: 'auto', label: 'تلقائي' },
        { value: 'javascript', label: 'JavaScript' },
        { value: 'typescript', label: 'TypeScript' },
        { value: 'python', label: 'Python' },
        { value: 'tsx', label: 'React' },
        { value: 'html', label: 'HTML' },
        { value: 'css', label: 'CSS' },
      ],
    },
  ],
  run(input, options) {
    const lang = (options.lang && options.lang !== 'auto' ? options.lang : detectLanguage(input)) as CodeLang
    const customName = extractName(input)
    const blocks: Block[] = []

    if (lang === 'html' || lang === 'tsx' || lang === 'css') {
      const intent = UI_INTENTS.find((i) => i.match.test(input)) ?? UI_INTENTS[UI_INTENTS.length - 1]
      const name = customName ?? UI_DEFAULT_NAMES[intent.id]
      blocks.push({ kind: 'heading', content: intent.title })
      blocks.push({
        kind: 'text',
        content: `تم تحليل طلبك وتوليد ${intent.title} بلغة ${lang === 'tsx' ? 'React' : lang.toUpperCase()} بتصميم داكن متوافق مع لمسات النيون.`,
      })
      blocks.push({ kind: 'code', lang, content: intent.build(lang as UiLang, name), title: lang === 'tsx' ? `${name}.tsx` : lang === 'css' ? 'style.css' : 'index.html' })
      if (lang === 'html') {
        blocks.push({ kind: 'code', lang: 'css', content: intent.build('css', name), title: 'style.css' })
      }
      blocks.push({
        kind: 'list',
        items: [
          'يدعم الكود اتجاه RTL للنصوص العربية.',
          'الألوان مبنية على لوحة داكنة مع لون سماوي مميز.',
          'يمكنك تحديد اسم مخصص بكتابة: باسم MyComponent',
        ],
      })
      return { blocks }
    }

    const logicLang = lang as LogicLang
    const intent = LOGIC_INTENTS.find((i) => i.match.test(input))

    if (!intent) {
      const name = customName ?? 'processInput'
      blocks.push({ kind: 'heading', content: 'هيكل دالة جاهز' })
      blocks.push({
        kind: 'note',
        tone: 'info',
        content: 'لم أتعرف على نمط محدد في طلبك، لذلك أنشأت هيكلاً احترافياً قابلاً للتوسعة. جرّب كلمات مثل: فرز، جلب API، بريد، كلمة مرور، فيبوناتشي، أولي، debounce، كلاس.',
      })
      const code =
        logicLang === 'python'
          ? `def ${snake(name)}(data):
    """${input.replace(/"/g, "'").slice(0, 80)}"""
    if not data:
        raise ValueError("البيانات المدخلة فارغة")

    result = []
    for item in data:
        # عالج كل عنصر هنا
        result.append(item)

    return result


print(${snake(name)}([1, 2, 3]))`
          : `/**
 * ${input.replace(/\*\//g, '').slice(0, 80)}
 */
export function ${name}(data${logicLang === 'typescript' ? ': unknown[]' : ''}) {
  if (!Array.isArray(data) || data.length === 0) {
    throw new Error('البيانات المدخلة فارغة')
  }

  return data.map((item) => {
    // عالج كل عنصر هنا
    return item
  })
}

console.log(${name}([1, 2, 3]))`
      blocks.push({ kind: 'code', lang: logicLang, content: code, title: logicLang === 'python' ? 'main.py' : `index.${logicLang === 'typescript' ? 'ts' : 'js'}` })
      return { blocks }
    }

    const name = customName ?? intent.defaultName
    blocks.push({ kind: 'heading', content: intent.title })
    blocks.push({ kind: 'text', content: intent.explain })
    blocks.push({
      kind: 'code',
      lang: logicLang,
      content: intent.build(logicLang, name),
      title: logicLang === 'python' ? `${snake(name)}.py` : `${name}.${logicLang === 'typescript' ? 'ts' : 'js'}`,
    })
    blocks.push({
      kind: 'list',
      items: [
        `اللغة المكتشفة: ${logicLang === 'python' ? 'Python' : logicLang === 'typescript' ? 'TypeScript' : 'JavaScript'}`,
        'الكود جاهز للتشغيل مباشرة ويتضمن مثالاً للاستخدام.',
        'لتغيير اسم الدالة اكتب في طلبك: باسم myFunction',
      ],
    })
    return { blocks }
  },
}
