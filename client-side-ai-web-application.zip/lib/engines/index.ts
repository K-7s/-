import type { Engine, EngineId } from '../types'
import { codeGeneratorEngine } from './code-generator'
import { luauHelperEngine } from './luau-helper'
import { promptBuilderEngine } from './prompt-builder'
import { textFormatterEngine } from './text-formatter'

export const ENGINES: Engine[] = [luauHelperEngine, codeGeneratorEngine, textFormatterEngine, promptBuilderEngine]

export function getEngine(id: EngineId): Engine {
  return ENGINES.find((e) => e.id === id) ?? ENGINES[0]
}
