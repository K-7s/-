export type CodeLang =
  | 'luau'
  | 'javascript'
  | 'typescript'
  | 'tsx'
  | 'python'
  | 'html'
  | 'css'
  | 'json'
  | 'text'

export type Block =
  | { kind: 'heading'; content: string }
  | { kind: 'text'; content: string }
  | { kind: 'list'; items: string[]; ordered?: boolean }
  | { kind: 'code'; lang: CodeLang; content: string; title?: string }
  | { kind: 'note'; tone: 'info' | 'warn' | 'success'; content: string }

export type EngineResult = {
  blocks: Block[]
}

export type EngineOption = {
  id: string
  label: string
  choices: { value: string; label: string }[]
}

export type EngineId = 'code' | 'luau' | 'formatter' | 'prompt'

export type Engine = {
  id: EngineId
  name: string
  tagline: string
  placeholder: string
  suggestions: string[]
  options: EngineOption[]
  run: (input: string, options: Record<string, string>) => EngineResult
}
