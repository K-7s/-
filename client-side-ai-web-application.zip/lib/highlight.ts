import type { CodeLang } from './types'

export type TokenType = 'keyword' | 'string' | 'number' | 'comment' | 'function' | 'builtin' | 'plain'
export type Token = { type: TokenType; value: string }

const KEYWORDS: Partial<Record<CodeLang, string[]>> = {
  luau: [
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function', 'if', 'in',
    'local', 'nil', 'not', 'or', 'repeat', 'return', 'then', 'true', 'until', 'while', 'continue', 'type',
  ],
  javascript: [
    'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'do', 'switch', 'case',
    'break', 'continue', 'new', 'class', 'extends', 'import', 'export', 'from', 'default', 'async',
    'await', 'try', 'catch', 'finally', 'throw', 'typeof', 'instanceof', 'of', 'in', 'true', 'false',
    'null', 'undefined', 'this', 'static', 'get', 'set',
  ],
  python: [
    'def', 'return', 'if', 'elif', 'else', 'for', 'while', 'in', 'not', 'and', 'or', 'import', 'from',
    'as', 'class', 'try', 'except', 'finally', 'raise', 'with', 'lambda', 'yield', 'pass', 'break',
    'continue', 'True', 'False', 'None', 'is', 'async', 'await', 'self',
  ],
  css: ['@media', '@keyframes', 'important', 'from', 'to'],
  json: ['true', 'false', 'null'],
}
KEYWORDS.typescript = [
  ...(KEYWORDS.javascript ?? []),
  'type', 'interface', 'enum', 'implements', 'private', 'public', 'readonly', 'as', 'keyof', 'number',
  'string', 'boolean', 'void', 'unknown', 'never', 'any',
]
KEYWORDS.tsx = KEYWORDS.typescript

const BUILTINS: Partial<Record<CodeLang, string[]>> = {
  luau: [
    'game', 'workspace', 'script', 'Instance', 'Vector3', 'CFrame', 'Color3', 'BrickColor', 'UDim2',
    'TweenInfo', 'Enum', 'task', 'print', 'warn', 'error', 'pairs', 'ipairs', 'math', 'string', 'table',
    'tostring', 'tonumber', 'typeof', 'pcall', 'require', 'os', 'tick', 'self',
  ],
  javascript: ['console', 'document', 'window', 'Math', 'JSON', 'Promise', 'Array', 'Object', 'Date', 'fetch', 'Number', 'String', 'Error', 'Set', 'Map'],
  python: ['print', 'len', 'range', 'list', 'dict', 'str', 'int', 'float', 'open', 'enumerate', 'sorted', 'random', 'string', 'requests', 'json'],
}
BUILTINS.typescript = BUILTINS.javascript
BUILTINS.tsx = [...(BUILTINS.javascript ?? []), 'React', 'useState', 'useEffect']

function commentPattern(lang: CodeLang): string {
  switch (lang) {
    case 'luau':
      return String.raw`--\[\[[\s\S]*?\]\]|--[^\n]*`
    case 'python':
      return String.raw`#[^\n]*`
    case 'html':
      return String.raw`<!--[\s\S]*?-->`
    case 'css':
      return String.raw`\/\*[\s\S]*?\*\/`
    case 'json':
    case 'text':
      return String.raw`(?!)`
    default:
      return String.raw`\/\/[^\n]*|\/\*[\s\S]*?\*\/`
  }
}

function stringPattern(lang: CodeLang): string {
  const base = String.raw`"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'`
  if (lang === 'luau') return String.raw`\[\[[\s\S]*?\]\]|` + base
  if (lang === 'javascript' || lang === 'typescript' || lang === 'tsx') return base + String.raw`|\x60(?:\\.|[^\x60\\])*\x60`
  if (lang === 'python') return String.raw`"""[\s\S]*?"""|f?` + base.replace(/^/, '')
  return base
}

const cache = new Map<CodeLang, RegExp>()

function getRegex(lang: CodeLang): RegExp {
  const cached = cache.get(lang)
  if (cached) return cached
  const ident = lang === 'css' ? String.raw`@?[A-Za-z_-][\w-]*` : String.raw`[A-Za-z_$@][\w$]*`
  const pattern =
    `(${commentPattern(lang)})|(${stringPattern(lang)})|(#[0-9a-fA-F]{3,8}\\b|\\b\\d+(?:\\.\\d+)?(?:px|rem|em|ms|s|%|vh|vw)?\\b)|(${ident})`
  const re = new RegExp(pattern, 'g')
  cache.set(lang, re)
  return re
}

function tokenizeHtml(code: string): Token[] {
  const tokens: Token[] = []
  const re = /(<!--[\s\S]*?-->)|(<\/?[a-zA-Z][\w-]*|\/?>)|("[^"]*"|'[^']*')|(\s[a-zA-Z-:@]+(?==))/g
  let last = 0
  let m: RegExpExecArray | null
  while ((m = re.exec(code))) {
    if (m.index > last) tokens.push({ type: 'plain', value: code.slice(last, m.index) })
    if (m[1]) tokens.push({ type: 'comment', value: m[1] })
    else if (m[2]) tokens.push({ type: 'keyword', value: m[2] })
    else if (m[3]) tokens.push({ type: 'string', value: m[3] })
    else if (m[4]) tokens.push({ type: 'function', value: m[4] })
    last = re.lastIndex
  }
  if (last < code.length) tokens.push({ type: 'plain', value: code.slice(last) })
  return tokens
}

export function tokenize(code: string, lang: CodeLang): Token[] {
  if (lang === 'text') return [{ type: 'plain', value: code }]
  if (lang === 'html') return tokenizeHtml(code)

  const keywords = new Set(KEYWORDS[lang] ?? [])
  const builtins = new Set(BUILTINS[lang] ?? [])
  const re = getRegex(lang)
  re.lastIndex = 0
  const tokens: Token[] = []
  let last = 0
  let m: RegExpExecArray | null

  while ((m = re.exec(code))) {
    if (m[0] === '') {
      re.lastIndex++
      continue
    }
    if (m.index > last) tokens.push({ type: 'plain', value: code.slice(last, m.index) })
    const [full, comment, str, num, ident] = m
    if (comment) tokens.push({ type: 'comment', value: comment })
    else if (str) tokens.push({ type: lang === 'json' && /^\s*:/.test(code.slice(re.lastIndex)) ? 'function' : 'string', value: str })
    else if (num) tokens.push({ type: 'number', value: num })
    else if (ident) {
      const next = code.slice(re.lastIndex).match(/^\s*([(:])/)
      if (keywords.has(ident)) tokens.push({ type: 'keyword', value: ident })
      else if (builtins.has(ident)) tokens.push({ type: 'builtin', value: ident })
      else if (lang === 'css' && next?.[1] === ':') tokens.push({ type: 'function', value: ident })
      else if (next?.[1] === '(') tokens.push({ type: 'function', value: ident })
      else tokens.push({ type: 'plain', value: ident })
    } else tokens.push({ type: 'plain', value: full })
    last = re.lastIndex
  }
  if (last < code.length) tokens.push({ type: 'plain', value: code.slice(last) })
  return tokens
}

export const LANG_LABELS: Record<CodeLang, string> = {
  luau: 'Luau',
  javascript: 'JavaScript',
  typescript: 'TypeScript',
  tsx: 'React TSX',
  python: 'Python',
  html: 'HTML',
  css: 'CSS',
  json: 'JSON',
  text: 'نص',
}
