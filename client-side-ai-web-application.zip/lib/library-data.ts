import type { CodeLang } from './types'

export type LibraryCategory = 'luau' | 'prompts' | 'web' | 'tools'

export type LibraryItem = {
  id: string
  title: string
  description: string
  category: LibraryCategory
  lang: CodeLang
  tags: string[]
  content: string
}

export const LIBRARY_CATEGORIES: { id: LibraryCategory | 'all'; label: string }[] = [
  { id: 'all', label: 'الكل' },
  { id: 'luau', label: 'سكربتات Luau' },
  { id: 'prompts', label: 'قوالب برومبت' },
  { id: 'web', label: 'أكواد ويب' },
  { id: 'tools', label: 'أدوات مساعدة' },
]

export const LIBRARY_ITEMS: LibraryItem[] = [
  {
    id: 'luau-remote-security',
    title: 'RemoteEvent آمن مع تحقق',
    description: 'نمط آمن لاستقبال طلبات العميل مع التحقق من النوع ومعدل الطلبات.',
    category: 'luau',
    lang: 'luau',
    tags: ['أمان', 'RemoteEvent', 'Server'],
    content: `local ReplicatedStorage = game:GetService("ReplicatedStorage")

local remote = Instance.new("RemoteEvent")
remote.Name = "BuyItem"
remote.Parent = ReplicatedStorage

local RATE_LIMIT = 0.5
local lastCall = {}

remote.OnServerEvent:Connect(function(player, itemId)
	if typeof(itemId) ~= "string" or #itemId > 32 then
		return
	end

	local now = os.clock()
	if lastCall[player] and now - lastCall[player] < RATE_LIMIT then
		return
	end
	lastCall[player] = now

	print(player.Name .. " طلب شراء: " .. itemId)
end)`,
  },
  {
    id: 'luau-tween-gui',
    title: 'ظهور واجهة بحركة ناعمة',
    description: 'تأثير ظهور وتكبير لإطار GUI باستخدام TweenService.',
    category: 'luau',
    lang: 'luau',
    tags: ['GUI', 'Tween', 'LocalScript'],
    content: `local TweenService = game:GetService("TweenService")

local frame = script.Parent
local targetSize = frame.Size

frame.Size = UDim2.fromScale(0, 0)
frame.Visible = true

TweenService:Create(frame, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
	Size = targetSize,
}):Play()`,
  },
  {
    id: 'luau-module-config',
    title: 'ModuleScript للإعدادات',
    description: 'ملف إعدادات مركزي قابل للمشاركة بين السكربتات.',
    category: 'luau',
    lang: 'luau',
    tags: ['ModuleScript', 'تنظيم'],
    content: `-- ReplicatedStorage › Config (ModuleScript)
local Config = {}

Config.Currency = "Coins"
Config.StartingCoins = 100
Config.WalkSpeed = 16
Config.SprintSpeed = 28

Config.Shop = {
	Sword = { price = 250, damage = 20 },
	Shield = { price = 400, defense = 15 },
}

return table.freeze(Config)

-- الاستخدام:
-- local Config = require(game.ReplicatedStorage.Config)
-- print(Config.Shop.Sword.price)`,
  },
  {
    id: 'luau-leaderboard',
    title: 'لوحة متصدرين عالمية',
    description: 'استخدام OrderedDataStore لعرض أفضل 10 لاعبين.',
    category: 'luau',
    lang: 'luau',
    tags: ['DataStore', 'Leaderboard'],
    content: `local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")

local board = DataStoreService:GetOrderedDataStore("TopCoins_v1")

local function updateBoard()
	for _, player in ipairs(Players:GetPlayers()) do
		local coins = player:FindFirstChild("leaderstats") and player.leaderstats:FindFirstChild("Coins")
		if coins then
			pcall(function()
				board:SetAsync(player.UserId, coins.Value)
			end)
		end
	end

	local ok, pages = pcall(function()
		return board:GetSortedAsync(false, 10)
	end)
	if not ok then return end

	for rank, entry in ipairs(pages:GetCurrentPage()) do
		local name = Players:GetNameFromUserIdAsync(tonumber(entry.key))
		print(rank .. ". " .. name .. " — " .. entry.value)
	end
end

while true do
	updateBoard()
	task.wait(60)
end`,
  },
  {
    id: 'luau-proximity-shop',
    title: 'متجر بزر ProximityPrompt',
    description: 'شراء عنصر عند الاقتراب من NPC أو جزء والضغط على E.',
    category: 'luau',
    lang: 'luau',
    tags: ['Shop', 'ProximityPrompt'],
    content: `local part = script.Parent
local PRICE = 100
local ITEM_NAME = "Sword"

local prompt = Instance.new("ProximityPrompt")
prompt.ActionText = "شراء (" .. PRICE .. ")"
prompt.ObjectText = ITEM_NAME
prompt.Parent = part

prompt.Triggered:Connect(function(player)
	local coins = player.leaderstats and player.leaderstats:FindFirstChild("Coins")
	local tool = game.ServerStorage:FindFirstChild(ITEM_NAME)
	if not coins or not tool then return end

	if coins.Value >= PRICE then
		coins.Value -= PRICE
		tool:Clone().Parent = player.Backpack
	end
end)`,
  },
  {
    id: 'prompt-code-review',
    title: 'مراجعة كود احترافية',
    description: 'قالب لطلب مراجعة شاملة لأي كود من نموذج ذكاء اصطناعي.',
    category: 'prompts',
    lang: 'text',
    tags: ['مراجعة', 'برمجة'],
    content: `أنت مهندس برمجيات أول متخصص في مراجعة الأكواد.

راجع الكود التالي وقدّم:
1. الأخطاء المنطقية والثغرات الأمنية (مع رقم السطر).
2. مشاكل الأداء وطرق تحسينها.
3. مدى وضوح الأسماء وتنظيم الكود.
4. نسخة محسّنة كاملة من الكود.

رتّب الملاحظات حسب الأولوية: حرجة ← مهمة ← تحسينات.

الكود:
[الصق الكود هنا]`,
  },
  {
    id: 'prompt-game-design',
    title: 'تصميم فكرة لعبة روبلوكس',
    description: 'يولّد وثيقة تصميم لعبة كاملة من فكرة بسيطة.',
    category: 'prompts',
    lang: 'text',
    tags: ['روبلوكس', 'تصميم ألعاب'],
    content: `أنت مصمم ألعاب محترف على منصة Roblox.

فكرتي: [اكتب فكرتك هنا]

أنشئ وثيقة تصميم تتضمن:
- اسم اللعبة وجملة تعريفية جذابة
- حلقة اللعب الأساسية (Core Loop)
- أنظمة التقدم (Leaderstats، Rebirth، مستويات)
- أفكار لتحقيق الدخل (Game Passes، Developer Products)
- قائمة السكربتات المطلوبة ومكان كل سكربت
- خطة تطوير مقسّمة على 4 أسابيع`,
  },
  {
    id: 'prompt-explain',
    title: 'اشرح لي كأني مبتدئ',
    description: 'قالب لتبسيط أي مفهوم تقني باستخدام تشبيهات.',
    category: 'prompts',
    lang: 'text',
    tags: ['تعليم', 'تبسيط'],
    content: `اشرح لي مفهوم [المفهوم] كأني مبتدئ تماماً.

- ابدأ بتشبيه من الحياة اليومية.
- ثم قدّم التعريف التقني في جملتين.
- أعطني مثالاً عملياً قصيراً.
- اختم بثلاثة أسئلة لأختبر فهمي (مع الإجابات مخفية في النهاية).`,
  },
  {
    id: 'prompt-content',
    title: 'خطة محتوى لمدة أسبوع',
    description: 'جدول منشورات سوشيال ميديا جاهز للنشر.',
    category: 'prompts',
    lang: 'text',
    tags: ['تسويق', 'محتوى'],
    content: `أنت خبير تسويق محتوى.

المجال: [مجالك]
الجمهور: [الجمهور المستهدف]
المنصة: [انستقرام / تيك توك / X]

أنشئ خطة محتوى لمدة 7 أيام في جدول يحتوي على:
اليوم | نوع المحتوى | العنوان | النص الكامل | الوسوم | أفضل وقت للنشر`,
  },
  {
    id: 'web-copy-clipboard',
    title: 'نسخ إلى الحافظة مع بديل',
    description: 'دالة نسخ تعمل على كل المتصفحات مع fallback.',
    category: 'web',
    lang: 'javascript',
    tags: ['Clipboard', 'JS'],
    content: `export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    const textarea = document.createElement('textarea')
    textarea.value = text
    textarea.style.position = 'fixed'
    textarea.style.opacity = '0'
    document.body.appendChild(textarea)
    textarea.select()
    const ok = document.execCommand('copy')
    textarea.remove()
    return ok
  }
}`,
  },
  {
    id: 'web-glass-css',
    title: 'تأثير الزجاج (Glassmorphism)',
    description: 'كلاس CSS جاهز لبطاقات زجاجية داكنة.',
    category: 'web',
    lang: 'css',
    tags: ['CSS', 'تصميم'],
    content: `.glass {
  background: linear-gradient(160deg, rgba(255, 255, 255, 0.06), rgba(255, 255, 255, 0.015));
  backdrop-filter: blur(16px) saturate(140%);
  -webkit-backdrop-filter: blur(16px) saturate(140%);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
}

.glass:hover {
  box-shadow: 0 0 0 1px rgba(34, 211, 238, 0.35), 0 0 24px -6px rgba(34, 211, 238, 0.45);
}`,
  },
  {
    id: 'web-use-local',
    title: 'Hook لاكتشاف حجم الشاشة',
    description: 'React hook لمعرفة إذا كان الجهاز موبايل.',
    category: 'web',
    lang: 'tsx',
    tags: ['React', 'Hook'],
    content: `import { useSyncExternalStore } from 'react'

const QUERY = '(max-width: 768px)'

function subscribe(callback: () => void) {
  const media = window.matchMedia(QUERY)
  media.addEventListener('change', callback)
  return () => media.removeEventListener('change', callback)
}

export function useIsMobile() {
  return useSyncExternalStore(
    subscribe,
    () => window.matchMedia(QUERY).matches,
    () => false,
  )
}`,
  },
  {
    id: 'tool-format-number',
    title: 'تنسيق الأرقام والعملات بالعربية',
    description: 'استخدام Intl لعرض الأرقام بالصيغة العربية.',
    category: 'tools',
    lang: 'javascript',
    tags: ['Intl', 'تنسيق'],
    content: `const formatCurrency = (value, currency = 'SAR') =>
  new Intl.NumberFormat('ar-SA', { style: 'currency', currency }).format(value)

const formatCompact = (value) =>
  new Intl.NumberFormat('ar', { notation: 'compact' }).format(value)

const formatDate = (date) =>
  new Intl.DateTimeFormat('ar', { dateStyle: 'full' }).format(date)

console.log(formatCurrency(1250.5)) // ١٬٢٥٠٫٥٠ ر.س.
console.log(formatCompact(1500000)) // ١٫٥ مليون
console.log(formatDate(new Date()))`,
  },
  {
    id: 'tool-luau-format-number',
    title: 'اختصار الأرقام الكبيرة في Luau',
    description: 'تحويل 1500000 إلى 1.5M لعرضها في واجهات اللعبة.',
    category: 'tools',
    lang: 'luau',
    tags: ['Luau', 'تنسيق'],
    content: `local SUFFIXES = { "", "K", "M", "B", "T", "Qd" }

local function abbreviate(n: number): string
	local index = 1
	while math.abs(n) >= 1000 and index < #SUFFIXES do
		n /= 1000
		index += 1
	end
	local formatted = string.format("%.1f", n):gsub("%.0$", "")
	return formatted .. SUFFIXES[index]
end

print(abbreviate(950))       -- 950
print(abbreviate(1500))      -- 1.5K
print(abbreviate(2750000))   -- 2.8M`,
  },
  {
    id: 'tool-python-rename',
    title: 'إعادة تسمية ملفات دفعة واحدة',
    description: 'سكربت بايثون لإعادة تسمية كل الملفات في مجلد بترقيم.',
    category: 'tools',
    lang: 'python',
    tags: ['Python', 'أتمتة'],
    content: `from pathlib import Path


def batch_rename(folder: str, prefix: str = "file") -> None:
    files = sorted(p for p in Path(folder).iterdir() if p.is_file())
    for index, path in enumerate(files, start=1):
        new_name = f"{prefix}_{index:03d}{path.suffix}"
        path.rename(path.with_name(new_name))
        print(f"{path.name} → {new_name}")


batch_rename("./images", prefix="asset")`,
  },
]
