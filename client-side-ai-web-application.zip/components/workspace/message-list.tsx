'use client'

import { Sparkles } from 'lucide-react'
import type { Block, Engine, EngineId } from '@/lib/types'
import { ResponseRenderer } from '../response-renderer'
import { ENGINE_ICONS } from './engine-icon'
import { StreamingResponse } from './streaming-response'
import { ThinkingIndicator } from './thinking-indicator'
import { getEngine } from '@/lib/engines'

export type Message =
  | { id: string; role: 'user'; engineId: EngineId; content: string }
  | {
      id: string
      role: 'assistant'
      engineId: EngineId
      status: 'thinking' | 'streaming' | 'done'
      blocks: Block[]
      elapsed?: number
    }

type Props = {
  messages: Message[]
  engine: Engine
  onSuggestion: (text: string) => void
  onDone: (id: string) => void
  onTick: () => void
}

export function MessageList({ messages, engine, onSuggestion, onDone, onTick }: Props) {
  if (messages.length === 0) {
    const Icon = ENGINE_ICONS[engine.id]
    return (
      <div className="mx-auto flex h-full max-w-xl flex-col items-center justify-center gap-6 py-6 text-center">
        <div className="relative">
          <div className="absolute inset-0 rounded-2xl bg-primary/30 blur-2xl" aria-hidden="true" />
          <span className="neon-ring relative flex size-14 items-center justify-center rounded-2xl bg-[#0a0a0a] text-primary">
            <Icon className="size-6" aria-hidden="true" />
          </span>
        </div>
        <div className="flex flex-col gap-2">
          <h3 className="text-balance text-xl font-semibold">كيف يمكن لـ {engine.name} مساعدتك؟</h3>
          <p className="text-pretty text-sm leading-relaxed text-muted-foreground">{engine.placeholder}</p>
        </div>
        <div className="grid w-full gap-2 sm:grid-cols-2">
          {engine.suggestions.slice(0, 4).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => onSuggestion(s)}
              className="group flex items-start gap-2 rounded-xl border border-white/[0.06] bg-white/[0.02] p-3 text-start text-sm text-foreground/80 transition-all hover:border-primary/30 hover:bg-primary/[0.04] hover:text-foreground"
            >
              <Sparkles className="mt-0.5 size-3.5 shrink-0 text-primary/70 group-hover:text-primary" aria-hidden="true" />
              <span className="line-clamp-2 break-all" dir="auto">
                {s}
              </span>
            </button>
          ))}
        </div>
      </div>
    )
  }

  return (
    <ol className="mx-auto flex max-w-3xl flex-col gap-6" aria-live="polite">
      {messages.map((m) => {
        if (m.role === 'user') {
          return (
            <li key={m.id} className="flex justify-start">
              <div className="scrollbar-thin max-h-48 max-w-[85%] overflow-y-auto whitespace-pre-wrap break-words rounded-2xl rounded-ss-sm bg-primary/[0.12] px-4 py-2.5 text-sm leading-relaxed text-foreground" dir="auto">
                {m.content}
              </div>
            </li>
          )
        }

        const Icon = ENGINE_ICONS[m.engineId]
        return (
          <li key={m.id} className="flex gap-3 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <span className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg bg-white/5 text-primary">
              <Icon className="size-3.5" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="mb-2 flex items-center gap-2 text-xs text-muted-foreground">
                <span className="font-medium text-foreground/70">{getEngine(m.engineId).name}</span>
                {m.elapsed !== undefined && m.status === 'done' && (
                  <span className="font-mono text-[10px]" dir="ltr">
                    {m.elapsed}ms
                  </span>
                )}
              </div>
              {m.status === 'thinking' && <ThinkingIndicator />}
              {m.status === 'streaming' && (
                <StreamingResponse blocks={m.blocks} onDone={() => onDone(m.id)} onTick={onTick} />
              )}
              {m.status === 'done' && <ResponseRenderer blocks={m.blocks} codeDownloadName="script" />}
            </div>
          </li>
        )
      })}
    </ol>
  )
}
