'use client'

import { ShieldCheck } from 'lucide-react'
import { ENGINES } from '@/lib/engines'
import type { EngineId } from '@/lib/types'
import { cn } from '@/lib/utils'
import { ENGINE_ICONS } from './engine-icon'

type Props = {
  active: EngineId
  onChange: (id: EngineId) => void
}

export function EnginePicker({ active, onChange }: Props) {
  return (
    <aside className="flex flex-col gap-3">
      <p className="hidden px-1 text-xs font-medium text-muted-foreground lg:block">المحركات الذكية</p>
      <div role="tablist" aria-label="اختر المحرك" className="scrollbar-thin -mx-1 flex gap-2 overflow-x-auto px-1 pb-1 lg:flex-col lg:overflow-visible">
        {ENGINES.map((engine) => {
          const Icon = ENGINE_ICONS[engine.id]
          const selected = engine.id === active
          return (
            <button
              key={engine.id}
              type="button"
              role="tab"
              aria-selected={selected}
              onClick={() => onChange(engine.id)}
              className={cn(
                'group flex shrink-0 items-center gap-3 rounded-xl border px-3 py-2.5 text-start transition-all lg:py-3',
                selected
                  ? 'neon-ring border-transparent bg-primary/[0.07]'
                  : 'border-white/[0.06] bg-white/[0.02] hover:border-white/15 hover:bg-white/[0.04]',
              )}
            >
              <span
                className={cn(
                  'flex size-8 shrink-0 items-center justify-center rounded-lg transition-colors',
                  selected ? 'bg-primary text-primary-foreground' : 'bg-white/5 text-muted-foreground group-hover:text-foreground',
                )}
              >
                <Icon className="size-4" aria-hidden="true" />
              </span>
              <span className="min-w-0">
                <span className={cn('block text-sm font-medium', selected ? 'text-foreground' : 'text-foreground/80')}>
                  {engine.name}
                </span>
                <span className="hidden truncate text-[11px] text-muted-foreground lg:block">{engine.tagline}</span>
              </span>
            </button>
          )
        })}
      </div>

      <div className="glass hidden rounded-xl p-4 lg:block">
        <div className="flex items-center gap-2 text-sm font-medium">
          <ShieldCheck className="size-4 text-primary" aria-hidden="true" />
          خصوصية كاملة
        </div>
        <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
          جميع المحركات تعمل داخل متصفحك عبر منطق JavaScript ذكي. لا خوادم، لا مفاتيح API، ولا تُرسل بياناتك لأي مكان.
        </p>
      </div>
    </aside>
  )
}
