'use client'

import { useEffect, useState } from 'react'

const STEPS = ['تحليل الطلب…', 'اكتشاف النمط المناسب…', 'تجميع الاستجابة…']

export function ThinkingIndicator() {
  const [step, setStep] = useState(0)

  useEffect(() => {
    const id = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 320)
    return () => clearInterval(id)
  }, [])

  return (
    <div className="flex items-center gap-3" role="status" aria-live="polite">
      <span className="flex gap-1" aria-hidden="true">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="size-1.5 animate-bounce rounded-full bg-primary"
            style={{ animationDelay: `${i * 120}ms` }}
          />
        ))}
      </span>
      <span className="text-sm text-muted-foreground">{STEPS[step]}</span>
      <span className="h-px flex-1 overflow-hidden rounded-full bg-white/5">
        <span className="block h-full w-1/3 animate-pulse bg-gradient-to-l from-primary/0 via-primary to-primary/0" />
      </span>
    </div>
  )
}
