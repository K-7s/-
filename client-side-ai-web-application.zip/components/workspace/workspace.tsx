'use client'

import { Cpu, RotateCcw } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import { ENGINES, getEngine } from '@/lib/engines'
import type { Block, EngineId } from '@/lib/types'
import { cn } from '@/lib/utils'
import { Composer } from './composer'
import { ENGINE_ICONS } from './engine-icon'
import { EnginePicker } from './engine-picker'
import { MessageList, type Message } from './message-list'

function initialOptions() {
  return Object.fromEntries(
    ENGINES.map((e) => [e.id, Object.fromEntries(e.options.map((o) => [o.id, o.choices[0].value]))]),
  ) as Record<EngineId, Record<string, string>>
}

export function Workspace() {
  const [engineId, setEngineId] = useState<EngineId>('luau')
  const [options, setOptions] = useState(initialOptions)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)
  const timers = useRef<ReturnType<typeof setTimeout>[]>([])

  const engine = getEngine(engineId)
  const Icon = ENGINE_ICONS[engineId]
  const busy = messages.some((m) => m.role === 'assistant' && m.status !== 'done')

  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages.length, scrollToBottom])

  useEffect(() => {
    const pending = timers.current
    return () => pending.forEach(clearTimeout)
  }, [])

  function submit(text: string) {
    const prompt = text.trim()
    if (!prompt || busy) return

    const engineOptions = options[engineId]
    const userId = crypto.randomUUID()
    const assistantId = crypto.randomUUID()

    setMessages((prev) => [
      ...prev,
      { id: userId, role: 'user', engineId, content: prompt },
      { id: assistantId, role: 'assistant', engineId, status: 'thinking', blocks: [] },
    ])
    setInput('')

    const started = performance.now()
    const delay = 650 + Math.random() * 450
    timers.current.push(
      setTimeout(() => {
        let blocks: Block[]
        try {
          blocks = engine.run(prompt, engineOptions).blocks
        } catch {
          blocks = [{ kind: 'note', tone: 'warn', content: 'حدث خطأ غير متوقع أثناء المعالجة. حاول إعادة صياغة الطلب.' }]
        }
        const elapsed = Math.round(performance.now() - started)
        setMessages((prev) =>
          prev.map((m) => (m.id === assistantId ? { ...m, status: 'streaming', blocks, elapsed } : m)),
        )
      }, delay),
    )
  }

  const markDone = useCallback((id: string) => {
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, status: 'done' } : m)))
  }, [])

  function setOption(optionId: string, value: string) {
    setOptions((prev) => ({ ...prev, [engineId]: { ...prev[engineId], [optionId]: value } }))
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[17rem_1fr]">
      <EnginePicker active={engineId} onChange={setEngineId} />

      <section
        aria-label={`مساحة عمل ${engine.name}`}
        className="glass flex h-[calc(100dvh-11rem)] min-h-[560px] flex-col overflow-hidden rounded-2xl lg:h-[calc(100dvh-12rem)]"
      >
        <header className="flex flex-col gap-3 border-b border-white/[0.06] px-4 py-3 sm:px-5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <span className="neon-ring flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Icon className="size-4.5" aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <h2 className="truncate text-sm font-semibold">{engine.name}</h2>
                <p className="truncate text-xs text-muted-foreground">{engine.tagline}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="hidden items-center gap-1.5 rounded-full border border-white/[0.06] px-2.5 py-1 text-[11px] text-muted-foreground sm:inline-flex">
                <Cpu className="size-3 text-primary" aria-hidden="true" />
                معالجة محلية
              </span>
              <button
                type="button"
                onClick={() => setMessages([])}
                disabled={messages.length === 0 || busy}
                className="inline-flex h-8 items-center gap-1.5 rounded-lg px-2.5 text-xs text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground disabled:pointer-events-none disabled:opacity-40"
              >
                <RotateCcw className="size-3.5" aria-hidden="true" />
                محادثة جديدة
              </button>
            </div>
          </div>

          {engine.options.length > 0 && (
            <div className="flex flex-col gap-2">
              {engine.options.map((option) => (
                <div key={option.id} className="flex items-center gap-2">
                  <span className="shrink-0 text-xs text-muted-foreground">{option.label}:</span>
                  <div role="radiogroup" aria-label={option.label} className="scrollbar-thin -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
                    {option.choices.map((choice) => {
                      const selected = options[engineId][option.id] === choice.value
                      return (
                        <button
                          key={choice.value}
                          type="button"
                          role="radio"
                          aria-checked={selected}
                          onClick={() => setOption(option.id, choice.value)}
                          className={cn(
                            'shrink-0 rounded-full border px-3 py-1 text-xs transition-all',
                            selected
                              ? 'border-primary/50 bg-primary/10 text-primary'
                              : 'border-white/[0.07] text-muted-foreground hover:border-white/15 hover:text-foreground',
                          )}
                        >
                          {choice.label}
                        </button>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </header>

        <div ref={scrollRef} className="scrollbar-thin flex-1 overflow-y-auto px-4 py-5 sm:px-5">
          <MessageList
            messages={messages}
            engine={engine}
            onSuggestion={submit}
            onDone={markDone}
            onTick={scrollToBottom}
          />
        </div>

        <Composer
          value={input}
          onChange={setInput}
          onSubmit={() => submit(input)}
          placeholder={engine.placeholder}
          disabled={busy}
          suggestions={messages.length > 0 ? engine.suggestions : []}
          onSuggestion={submit}
        />
      </section>
    </div>
  )
}
