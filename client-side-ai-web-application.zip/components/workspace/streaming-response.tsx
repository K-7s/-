'use client'

import { useEffect, useEffectEvent, useState } from 'react'
import type { Block } from '@/lib/types'
import { ResponseRenderer, totalLength } from '../response-renderer'

type Props = {
  blocks: Block[]
  onDone: () => void
  onTick?: () => void
}

export function StreamingResponse({ blocks, onDone, onTick }: Props) {
  const [revealed, setRevealed] = useState(0)
  const total = totalLength(blocks)

  const finish = useEffectEvent(() => onDone())
  const tick = useEffectEvent(() => onTick?.())

  useEffect(() => {
    const charsPerFrame = Math.max(6, Math.ceil(total / 70))
    let frame = 0
    let current = 0
    const step = () => {
      current = Math.min(total, current + charsPerFrame)
      setRevealed(current)
      tick()
      if (current >= total) {
        finish()
        return
      }
      frame = requestAnimationFrame(step)
    }
    frame = requestAnimationFrame(step)
    return () => cancelAnimationFrame(frame)
  }, [total])

  return <ResponseRenderer blocks={blocks} revealed={revealed} />
}
