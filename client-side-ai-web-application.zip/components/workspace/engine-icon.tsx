import { CodeXml, Gamepad2, Type, WandSparkles, type LucideIcon } from 'lucide-react'
import type { EngineId } from '@/lib/types'

export const ENGINE_ICONS: Record<EngineId, LucideIcon> = {
  luau: Gamepad2,
  code: CodeXml,
  formatter: Type,
  prompt: WandSparkles,
}
