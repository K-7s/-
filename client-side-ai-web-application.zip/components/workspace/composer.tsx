'use client'

import { ArrowUp } from 'lucide-react'
import type { KeyboardEvent } from 'react'
import { cn } from '@/lib/utils'

type Props = {
  value: string
  onChange: (value: string) => void
  onSubmit: () => void
  placeholder: string
  disabled: boolean
  suggestions: string[]
  onSuggestion: (text: string) => void
}

export function Composer({ value, onChange, onSubmit, placeholder, disabled, suggestions, onSuggestion }: Props) {
  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key !== 'Enter' || e.shiftKey) return
    if (e.nativeEvent.isComposing || e.keyCode === 229) return
    e.preventDefault()
    onSubmit()
  }

  return (
    <div className="border-t border-white/[0.06] bg-black/20 px-3 pt-3 pb-3 sm:px-4">
      {suggestions.length > 0 && (
        <div className="scrollbar-thin -mx-1 mb-2.5 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
          {suggestions.map((s) => (
            <button
              key={s}
              type="button"
              disabled={disabled}
              onClick={() => onSuggestion(s)}
              className="max-w-64 shrink-0 truncate rounded-full border border-white/[0.06] px-3 py-1 text-xs text-muted-foreground transition-colors hover:border-primary/30 hover:text-foreground disabled:opacity-40"
              dir="auto"
            >
              {s}
            </button>
          ))}
        </div>
      )}
      <form
        onSubmit={(e) => {
          e.preventDefault()
          onSubmit()
        }}
        className="flex items-end gap-2 rounded-xl border border-white/[0.08] bg-[#0a0a0a] p-1.5 transition-all focus-within:border-primary/40 focus-within:shadow-[0_0_0_3px_rgb(34_211_238/0.12)]"
      >
        <label htmlFor="prompt-input" className="sr-only">
          اكتب طلبك
        </label>
        <textarea
          id="prompt-input"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          rows={1}
          dir="auto"
          className="field-sizing-content scrollbar-thin max-h-40 min-h-10 flex-1 resize-none bg-transparent px-2.5 py-2 text-sm leading-relaxed text-foreground outline-none placeholder:text-muted-foreground/70"
        />
        <button
          type="submit"
          disabled={disabled || !value.trim()}
          aria-label="إرسال"
          className={cn(
            'flex size-9 shrink-0 items-center justify-center rounded-lg transition-all',
            'bg-primary text-primary-foreground hover:shadow-[0_0_20px_-2px_rgb(34_211_238/0.7)] disabled:bg-white/5 disabled:text-muted-foreground disabled:shadow-none',
          )}
        >
          <ArrowUp className="size-4" aria-hidden="true" />
        </button>
      </form>
      <p className="mt-2 hidden text-center text-[11px] text-muted-foreground/70 sm:block">
        Enter للإرسال · Shift + Enter لسطر جديد
      </p>
    </div>
  )
}
