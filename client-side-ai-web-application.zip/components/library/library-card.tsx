'use client'

import { Check, ChevronDown, Copy } from 'lucide-react'
import { useState } from 'react'
import { useCopy } from '@/hooks/use-copy'
import { LANG_LABELS } from '@/lib/highlight'
import type { LibraryItem } from '@/lib/library-data'
import { cn } from '@/lib/utils'
import { CodeBlock } from '../code-block'

export function LibraryCard({ item }: { item: LibraryItem }) {
  const [expanded, setExpanded] = useState(false)
  const { copied, copy } = useCopy()

  return (
    <article className="glass group flex flex-col gap-3 rounded-2xl p-4 transition-all hover:border-white/15">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="text-sm font-semibold leading-snug">{item.title}</h3>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{item.description}</p>
        </div>
        <button
          type="button"
          onClick={() => copy(item.content)}
          aria-label={copied ? 'تم النسخ' : `نسخ ${item.title}`}
          className={cn(
            'flex size-9 shrink-0 items-center justify-center rounded-lg border transition-all',
            copied ? 'border-primary/50 bg-primary/15 text-primary' : 'border-white/[0.07] text-muted-foreground hover:border-primary/40 hover:text-primary',
          )}
        >
          {copied ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        <span className="rounded-md bg-primary/10 px-2 py-0.5 font-mono text-[10px] text-primary">{LANG_LABELS[item.lang]}</span>
        {item.tags.map((tag) => (
          <span key={tag} className="rounded-md bg-white/[0.04] px-2 py-0.5 text-[10px] text-muted-foreground">
            {tag}
          </span>
        ))}
      </div>

      <div className="relative">
        <CodeBlock code={item.content} lang={item.lang} maxHeight={expanded ? '32rem' : '9.5rem'} className="transition-all" />
        {!expanded && (
          <div className="pointer-events-none absolute inset-x-px bottom-px h-12 rounded-b-xl bg-gradient-to-t from-[#0a0a0a] to-transparent" aria-hidden="true" />
        )}
      </div>

      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        aria-expanded={expanded}
        className="mt-auto inline-flex items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs text-muted-foreground transition-colors hover:bg-white/[0.03] hover:text-foreground"
      >
        {expanded ? 'عرض أقل' : 'عرض الكود كاملاً'}
        <ChevronDown className={cn('size-3.5 transition-transform', expanded && 'rotate-180')} aria-hidden="true" />
      </button>
    </article>
  )
}
