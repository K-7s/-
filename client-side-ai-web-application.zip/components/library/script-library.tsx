'use client'

import { Search, SearchX } from 'lucide-react'
import { useDeferredValue, useMemo, useState } from 'react'
import { LIBRARY_CATEGORIES, LIBRARY_ITEMS, type LibraryCategory } from '@/lib/library-data'
import { cn } from '@/lib/utils'
import { LibraryCard } from './library-card'

export function ScriptLibrary() {
  const [category, setCategory] = useState<LibraryCategory | 'all'>('all')
  const [query, setQuery] = useState('')
  const deferredQuery = useDeferredValue(query)

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: LIBRARY_ITEMS.length }
    for (const item of LIBRARY_ITEMS) map[item.category] = (map[item.category] ?? 0) + 1
    return map
  }, [])

  const items = useMemo(() => {
    const q = deferredQuery.trim().toLowerCase()
    return LIBRARY_ITEMS.filter((item) => {
      if (category !== 'all' && item.category !== category) return false
      if (!q) return true
      return [item.title, item.description, ...item.tags].some((s) => s.toLowerCase().includes(q))
    })
  }, [category, deferredQuery])

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div role="tablist" aria-label="التصنيفات" className="scrollbar-thin -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
          {LIBRARY_CATEGORIES.map((c) => {
            const selected = c.id === category
            return (
              <button
                key={c.id}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => setCategory(c.id)}
                className={cn(
                  'inline-flex shrink-0 items-center gap-2 rounded-full border px-3.5 py-1.5 text-sm transition-all',
                  selected ? 'border-primary/50 bg-primary/10 text-primary' : 'border-white/[0.07] text-muted-foreground hover:text-foreground',
                )}
              >
                {c.label}
                <span className={cn('rounded-full px-1.5 text-[10px]', selected ? 'bg-primary/20' : 'bg-white/5')}>{counts[c.id] ?? 0}</span>
              </button>
            )
          })}
        </div>
        <div className="relative md:w-72">
          <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <label htmlFor="library-search" className="sr-only">
            ابحث في المكتبة
          </label>
          <input
            id="library-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث… (DataStore، تسويق، CSS)"
            className="h-10 w-full rounded-lg border border-white/[0.08] bg-[#0a0a0a] ps-9 pe-3 text-sm outline-none transition-all placeholder:text-muted-foreground/70 focus:border-primary/50 focus:shadow-[0_0_0_3px_rgb(34_211_238/0.12)]"
          />
        </div>
      </div>

      {items.length === 0 ? (
        <div className="glass flex flex-col items-center gap-2 rounded-2xl p-10 text-center">
          <SearchX className="size-6 text-muted-foreground" aria-hidden="true" />
          <p className="text-sm text-muted-foreground">لا توجد نتائج مطابقة لـ &quot;{query}&quot;</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {items.map((item) => (
            <LibraryCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  )
}
