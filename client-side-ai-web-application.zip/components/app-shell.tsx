'use client'

import { BookOpen, Bot, Cpu, Wrench, type LucideIcon } from 'lucide-react'
import { Activity, useState } from 'react'
import { cn } from '@/lib/utils'
import { ScriptGenerator } from './generator/script-generator'
import { ScriptLibrary } from './library/script-library'
import { Workspace } from './workspace/workspace'

type TabId = 'workspace' | 'generator' | 'library'

const TABS: { id: TabId; label: string; short: string; icon: LucideIcon; title: string; description: string }[] = [
  {
    id: 'workspace',
    label: 'مساحة العمل الذكية',
    short: 'المساعد',
    icon: Bot,
    title: 'مساعدك الذكي المحلي',
    description: 'أربعة محركات ذكية تعالج طلباتك فوراً داخل المتصفح.',
  },
  {
    id: 'generator',
    label: 'مولّد السكربتات',
    short: 'المولّد',
    icon: Wrench,
    title: 'مولّد سكربتات Luau',
    description: 'اختر النظام، خصّص المعاملات، واحصل على كود Roblox كامل وآمن.',
  },
  {
    id: 'library',
    label: 'المكتبة',
    short: 'المكتبة',
    icon: BookOpen,
    title: 'مكتبة السكربتات والبرومبتات',
    description: 'مجموعة مصنّفة من الأكواد والقوالب الجاهزة للنسخ بنقرة واحدة.',
  },
]

export function AppShell() {
  const [tab, setTab] = useState<TabId>('workspace')
  const current = TABS.find((t) => t.id === tab) ?? TABS[0]

  return (
    <div className="relative min-h-dvh overflow-x-hidden">
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-40 start-1/2 h-96 w-[48rem] -translate-x-1/2 rounded-full bg-primary/[0.07] blur-[120px] rtl:translate-x-1/2" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgb(255_255_255/0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgb(255_255_255/0.02)_1px,transparent_1px)] bg-[size:48px_48px] [mask-image:radial-gradient(ellipse_at_top,black_20%,transparent_70%)]" />
      </div>

      <header className="sticky top-0 z-30 border-b border-white/[0.06] bg-[#0a0a0a]/75 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <span className="neon-ring flex size-9 items-center justify-center rounded-xl bg-primary/10">
              <Cpu className="size-4.5 text-primary" aria-hidden="true" />
            </span>
            <div className="leading-tight">
              <p className="text-base font-bold tracking-tight">
                نَواة <span className="text-primary">AI</span>
              </p>
              <p className="hidden text-[11px] text-muted-foreground sm:block">ذكاء محلي · بدون API</p>
            </div>
          </div>

          <nav aria-label="الأقسام" className="flex items-center gap-1 rounded-xl border border-white/[0.06] bg-white/[0.02] p-1">
            {TABS.map((t) => {
              const Icon = t.icon
              const selected = t.id === tab
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  aria-current={selected ? 'page' : undefined}
                  className={cn(
                    'inline-flex h-8 items-center gap-2 rounded-lg px-2.5 text-xs font-medium transition-all sm:px-3 sm:text-sm',
                    selected ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                  <span className="hidden md:inline">{t.label}</span>
                  <span className="md:hidden">{t.short}</span>
                </button>
              )
            })}
          </nav>

          <span className="hidden items-center gap-2 rounded-full border border-primary/20 bg-primary/[0.06] px-3 py-1 text-xs text-primary lg:inline-flex">
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-60" />
              <span className="relative inline-flex size-2 rounded-full bg-primary" />
            </span>
            يعمل 100% على جهازك
          </span>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-5 sm:px-6 sm:py-6">
        <div className="mb-5 flex flex-col gap-1">
          <h1 className="text-balance text-xl font-bold tracking-tight sm:text-2xl">{current.title}</h1>
          <p className="text-pretty text-sm text-muted-foreground">{current.description}</p>
        </div>

        <Activity mode={tab === 'workspace' ? 'visible' : 'hidden'}>
          <Workspace />
        </Activity>
        <Activity mode={tab === 'generator' ? 'visible' : 'hidden'}>
          <ScriptGenerator />
        </Activity>
        <Activity mode={tab === 'library' ? 'visible' : 'hidden'}>
          <ScriptLibrary />
        </Activity>
      </main>

      <footer className="mx-auto max-w-7xl px-4 pb-6 text-center text-xs text-muted-foreground/70 sm:px-6">
        نَواة AI — جميع العمليات تتم محلياً في متصفحك. لا يتم إرسال أي بيانات.
      </footer>
    </div>
  )
}
