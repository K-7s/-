'use client'

import { AlertTriangle, CheckCircle2, Info } from 'lucide-react'
import type { Block } from '@/lib/types'
import { cn } from '@/lib/utils'
import { CodeBlock } from './code-block'

function blockLength(block: Block): number {
  if (block.kind === 'list') return block.items.reduce((n, item) => n + item.length, 0)
  return block.content.length
}

export function totalLength(blocks: Block[]) {
  return blocks.reduce((n, b) => n + blockLength(b), 0)
}

function sliceBlocks(blocks: Block[], budget: number): { blocks: Block[]; activeIndex: number } {
  const out: Block[] = []
  let remaining = budget
  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i]
    const len = blockLength(block)
    if (remaining >= len) {
      out.push(block)
      remaining -= len
      continue
    }
    if (block.kind === 'list') {
      const items: string[] = []
      for (const item of block.items) {
        if (remaining <= 0) break
        items.push(item.slice(0, remaining))
        remaining -= item.length
      }
      out.push({ ...block, items })
    } else {
      out.push({ ...block, content: block.content.slice(0, Math.max(0, remaining)) })
    }
    return { blocks: out, activeIndex: i }
  }
  return { blocks: out, activeIndex: -1 }
}

const NOTE_STYLES = {
  info: { icon: Info, className: 'border-primary/20 bg-primary/[0.06] text-primary' },
  warn: { icon: AlertTriangle, className: 'border-amber-400/20 bg-amber-400/[0.06] text-amber-300' },
  success: { icon: CheckCircle2, className: 'border-emerald-400/20 bg-emerald-400/[0.06] text-emerald-300' },
}

type Props = {
  blocks: Block[]
  revealed?: number
  codeDownloadName?: string
}

export function ResponseRenderer({ blocks, revealed, codeDownloadName }: Props) {
  const streaming = revealed !== undefined
  const { blocks: visible, activeIndex } = streaming ? sliceBlocks(blocks, revealed) : { blocks, activeIndex: -1 }

  return (
    <div className="flex flex-col gap-3.5">
      {visible.map((block, i) => {
        const isActive = streaming && i === activeIndex
        switch (block.kind) {
          case 'heading':
            return (
              <h3 key={i} className={cn('text-base font-semibold text-foreground', isActive && 'stream-caret')}>
                {block.content}
              </h3>
            )
          case 'text':
            return (
              <p key={i} className={cn('leading-relaxed text-foreground/80', isActive && 'stream-caret')}>
                {block.content}
              </p>
            )
          case 'list': {
            const ListTag = block.ordered ? 'ol' : 'ul'
            return (
              <ListTag
                key={i}
                className={cn('flex flex-col gap-1.5 ps-5 text-sm leading-relaxed text-foreground/75', block.ordered ? 'list-decimal' : 'list-disc', 'marker:text-primary')}
              >
                {block.items.map((item, j) => (
                  <li key={j} className={cn(isActive && j === block.items.length - 1 && 'stream-caret')}>
                    {item}
                  </li>
                ))}
              </ListTag>
            )
          }
          case 'code':
            return (
              <CodeBlock
                key={i}
                code={block.content}
                lang={block.lang}
                title={block.title}
                streaming={isActive}
                downloadName={codeDownloadName && block.lang !== 'text' ? block.title?.replace(/\.[^.]+$/, '') ?? codeDownloadName : undefined}
                maxHeight="28rem"
              />
            )
          case 'note': {
            const style = NOTE_STYLES[block.tone]
            const Icon = style.icon
            return (
              <div key={i} className={cn('flex items-start gap-2.5 rounded-lg border px-3 py-2.5 text-sm leading-relaxed', style.className)}>
                <Icon className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                <p className={cn(isActive && 'stream-caret')}>{block.content}</p>
              </div>
            )
          }
        }
      })}
    </div>
  )
}
