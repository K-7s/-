'use client'

import { Check, Copy, Download } from 'lucide-react'
import { useMemo } from 'react'
import { useCopy } from '@/hooks/use-copy'
import { LANG_LABELS, tokenize, type TokenType } from '@/lib/highlight'
import type { CodeLang } from '@/lib/types'
import { cn } from '@/lib/utils'

const TOKEN_CLASS: Record<TokenType, string> = {
  keyword: 'text-syntax-keyword',
  string: 'text-syntax-string',
  number: 'text-syntax-number',
  comment: 'text-syntax-comment italic',
  function: 'text-syntax-function',
  builtin: 'text-syntax-builtin',
  plain: 'text-foreground/90',
}

const EXTENSIONS: Record<CodeLang, string> = {
  luau: 'lua',
  javascript: 'js',
  typescript: 'ts',
  tsx: 'tsx',
  python: 'py',
  html: 'html',
  css: 'css',
  json: 'json',
  text: 'txt',
}

type CodeBlockProps = {
  code: string
  lang: CodeLang
  title?: string
  streaming?: boolean
  downloadName?: string
  maxHeight?: string
  className?: string
}

export function CodeBlock({ code, lang, title, streaming, downloadName, maxHeight, className }: CodeBlockProps) {
  const { copied, copy } = useCopy()
  const tokens = useMemo(() => tokenize(code, lang), [code, lang])
  const lineCount = code.split('\n').length

  function handleDownload() {
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${downloadName ?? 'code'}.${EXTENSIONS[lang]}`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className={cn('overflow-hidden rounded-xl border border-white/[0.07] bg-[#0a0a0a]', className)}>
      <div className="flex items-center justify-between gap-2 border-b border-white/[0.06] bg-white/[0.02] px-3 py-2">
        <div className="flex min-w-0 items-center gap-2">
          <span className="flex gap-1.5" aria-hidden="true">
            <span className="size-2.5 rounded-full bg-white/10" />
            <span className="size-2.5 rounded-full bg-white/10" />
            <span className="size-2.5 rounded-full bg-primary/60" />
          </span>
          <span className="truncate font-mono text-xs text-muted-foreground" dir="ltr">
            {title ?? LANG_LABELS[lang]}
          </span>
          {title && (
            <span className="hidden rounded-md bg-primary/10 px-1.5 py-0.5 font-mono text-[10px] text-primary sm:inline">
              {LANG_LABELS[lang]}
            </span>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-1">
          {downloadName && (
            <button
              type="button"
              onClick={handleDownload}
              disabled={streaming}
              className="inline-flex h-7 items-center gap-1.5 rounded-md px-2 text-xs text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground disabled:opacity-40"
            >
              <Download className="size-3.5" aria-hidden="true" />
              <span className="hidden sm:inline">تنزيل</span>
              <span className="sr-only sm:hidden">تنزيل الملف</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => copy(code)}
            disabled={streaming}
            aria-live="polite"
            className={cn(
              'inline-flex h-7 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium transition-all disabled:opacity-40',
              copied ? 'bg-primary/15 text-primary' : 'bg-white/[0.04] text-foreground/80 hover:bg-primary/10 hover:text-primary',
            )}
          >
            {copied ? <Check className="size-3.5" aria-hidden="true" /> : <Copy className="size-3.5" aria-hidden="true" />}
            {copied ? 'تم النسخ' : 'نسخ الكود'}
          </button>
        </div>
      </div>
      <div className="scrollbar-thin overflow-auto" style={{ maxHeight }} dir="ltr">
        <pre className="flex min-w-full py-3 font-mono text-[13px] leading-6">
          {lang !== 'text' && (
            <span aria-hidden="true" className="sticky left-0 select-none bg-[#0a0a0a] pr-3 pl-4 text-right text-white/20">
              {Array.from({ length: lineCount }, (_, i) => (
                <span key={i} className="block">
                  {i + 1}
                </span>
              ))}
            </span>
          )}
          <code className={cn('flex-1 pr-4', lang === 'text' ? 'whitespace-pre-wrap pl-4' : 'whitespace-pre', streaming && 'stream-caret')} dir={lang === 'text' ? 'auto' : 'ltr'}>
            {tokens.map((t, i) => (
              <span key={i} className={TOKEN_CLASS[t.type]}>
                {t.value}
              </span>
            ))}
          </code>
        </pre>
      </div>
    </div>
  )
}
