'use client'

import { Coins, Flag, Gift, Loader2, RotateCcw, Skull, Zap, type LucideIcon } from 'lucide-react'
import { useRef, useState } from 'react'
import { defaultValues, SCRIPT_TEMPLATES, type GeneratedFile } from '@/lib/luau-generator'
import { cn } from '@/lib/utils'
import { CodeBlock } from '../code-block'
import { GeneratorField } from './generator-field'

const TEMPLATE_ICONS: Record<string, LucideIcon> = {
  leaderstats: Coins,
  checkpoint: Flag,
  rebirth: RotateCcw,
  killbrick: Skull,
  daily: Gift,
}

type Values = Record<string, string | number | boolean>

export function ScriptGenerator() {
  const [templateId, setTemplateId] = useState(SCRIPT_TEMPLATES[0].id)
  const [values, setValues] = useState<Record<string, Values>>(() =>
    Object.fromEntries(SCRIPT_TEMPLATES.map((t) => [t.id, defaultValues(t)])),
  )
  const [output, setOutput] = useState<{ templateId: string; files: GeneratedFile[] } | null>(null)
  const [loading, setLoading] = useState(false)
  const [activeFile, setActiveFile] = useState(0)
  const outputRef = useRef<HTMLDivElement>(null)

  const template = SCRIPT_TEMPLATES.find((t) => t.id === templateId) ?? SCRIPT_TEMPLATES[0]
  const current = values[template.id]
  const showOutput = output?.templateId === template.id

  function update(fieldId: string, value: string | number | boolean) {
    setValues((prev) => ({ ...prev, [template.id]: { ...prev[template.id], [fieldId]: value } }))
  }

  function generate() {
    setLoading(true)
    setTimeout(() => {
      setOutput({ templateId: template.id, files: template.build(current) })
      setActiveFile(0)
      setLoading(false)
      if (window.matchMedia('(max-width: 1023px)').matches) {
        outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }
    }, 700)
  }

  const file = showOutput ? output.files[activeFile] ?? output.files[0] : null
  const lineCount = file ? file.code.split('\n').length : 0

  return (
    <div className="flex flex-col gap-5">
      <div role="tablist" aria-label="نوع السكربت" className="scrollbar-thin -mx-1 flex gap-2 overflow-x-auto px-1 pb-1 md:grid md:grid-cols-5 md:overflow-visible">
        {SCRIPT_TEMPLATES.map((t) => {
          const Icon = TEMPLATE_ICONS[t.id] ?? Zap
          const selected = t.id === template.id
          return (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={selected}
              onClick={() => setTemplateId(t.id)}
              className={cn(
                'flex w-44 shrink-0 flex-col items-start gap-2 rounded-xl border p-3.5 text-start transition-all md:w-auto',
                selected ? 'neon-ring border-transparent bg-primary/[0.07]' : 'glass hover:border-white/15',
              )}
            >
              <span className={cn('flex size-8 items-center justify-center rounded-lg', selected ? 'bg-primary text-primary-foreground' : 'bg-white/5 text-muted-foreground')}>
                <Icon className="size-4" aria-hidden="true" />
              </span>
              <span className="font-mono text-sm font-semibold" dir="ltr">
                {t.name}
              </span>
              <span className="line-clamp-2 text-xs leading-relaxed text-muted-foreground">{t.description}</span>
            </button>
          )
        })}
      </div>

      <div className="grid gap-5 lg:grid-cols-[22rem_1fr]">
        <form
          onSubmit={(e) => {
            e.preventDefault()
            generate()
          }}
          className="glass flex flex-col gap-4 self-start rounded-2xl p-5"
        >
          <div>
            <h2 className="text-sm font-semibold">إعدادات {template.name}</h2>
            <p className="mt-1 text-xs text-muted-foreground">خصّص المعاملات وسيتم تجميع كود Luau كامل محلياً.</p>
          </div>

          <div className="flex flex-col gap-3.5">
            {template.fields.map((field) => (
              <GeneratorField key={field.id} field={field} value={current[field.id]} onChange={(v) => update(field.id, v)} />
            ))}
          </div>

          <div className="flex gap-2 pt-1">
            <button
              type="submit"
              disabled={loading}
              className="inline-flex h-10 flex-1 items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-primary-foreground transition-all hover:shadow-[0_0_24px_-4px_rgb(34_211_238/0.7)] disabled:opacity-70"
            >
              {loading ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Zap className="size-4" aria-hidden="true" />}
              {loading ? 'جارٍ التجميع…' : 'توليد السكربت'}
            </button>
            <button
              type="button"
              onClick={() => setValues((prev) => ({ ...prev, [template.id]: defaultValues(template) }))}
              className="inline-flex h-10 items-center justify-center rounded-lg border border-white/[0.08] px-3 text-xs text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground"
            >
              استعادة الافتراضي
            </button>
          </div>
        </form>

        <div ref={outputRef} className="flex min-w-0 scroll-mt-24 flex-col gap-4">
          {loading && (
            <div className="glass flex flex-col gap-3 rounded-2xl p-5" role="status">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="size-4 animate-spin text-primary" aria-hidden="true" />
                جارٍ تجميع كود {template.name}…
              </div>
              {[90, 70, 82, 55, 76, 40].map((w, i) => (
                <div key={i} className="h-3 animate-pulse rounded bg-white/[0.05]" style={{ width: `${w}%`, animationDelay: `${i * 80}ms` }} />
              ))}
            </div>
          )}

          {!loading && file && showOutput && (
            <div className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="الملفات المولدة">
                  {output.files.map((f, i) => (
                    <button
                      key={f.name}
                      type="button"
                      role="tab"
                      aria-selected={i === activeFile}
                      onClick={() => setActiveFile(i)}
                      className={cn(
                        'rounded-lg border px-3 py-1.5 font-mono text-xs transition-all',
                        i === activeFile ? 'border-primary/40 bg-primary/10 text-primary' : 'border-white/[0.07] text-muted-foreground hover:text-foreground',
                      )}
                      dir="ltr"
                    >
                      {f.name}.lua
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{file.scriptType}</span>
                  <span className="size-1 rounded-full bg-white/20" aria-hidden="true" />
                  <span>{lineCount} سطر</span>
                </div>
              </div>

              <CodeBlock code={file.code} lang="luau" title={`${file.name}.lua`} downloadName={file.name} maxHeight="34rem" />

              <div className="glass rounded-2xl p-5">
                <h3 className="text-sm font-semibold">طريقة التركيب</h3>
                <ol className="mt-3 flex list-decimal flex-col gap-2 ps-5 text-sm leading-relaxed text-foreground/75 marker:text-primary">
                  {template.setup.map((step) => (
                    <li key={step}>{step}</li>
                  ))}
                </ol>
              </div>
            </div>
          )}

          {!loading && !showOutput && (
            <div className="glass flex min-h-80 flex-col items-center justify-center gap-3 rounded-2xl border-dashed p-8 text-center">
              <span className="neon-ring flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Zap className="size-5" aria-hidden="true" />
              </span>
              <h3 className="font-semibold">جاهز للتوليد</h3>
              <p className="max-w-sm text-pretty text-sm leading-relaxed text-muted-foreground">
                اختر نوع السكربت، عدّل الإعدادات، ثم اضغط &quot;توليد السكربت&quot; للحصول على كود Luau كامل وجاهز للصق في Roblox Studio.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
