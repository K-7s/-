'use client'

import { useId } from 'react'
import type { GeneratorField as Field } from '@/lib/luau-generator'
import { cn } from '@/lib/utils'

type Props = {
  field: Field
  value: string | number | boolean
  onChange: (value: string | number | boolean) => void
}

export function GeneratorField({ field, value, onChange }: Props) {
  const id = useId()

  if (field.type === 'boolean') {
    const checked = Boolean(value)
    return (
      <div className="flex items-center justify-between gap-3">
        <label htmlFor={id} className="text-sm text-foreground/85">
          {field.label}
        </label>
        <button
          id={id}
          type="button"
          role="switch"
          aria-checked={checked}
          onClick={() => onChange(!checked)}
          className={cn(
            'relative h-6 w-11 shrink-0 rounded-full border transition-colors',
            checked ? 'border-primary/50 bg-primary/80' : 'border-white/10 bg-white/[0.06]',
          )}
        >
          <span
            className={cn(
              'absolute top-0.5 size-4.5 rounded-full bg-white shadow transition-all',
              checked ? 'start-[1.4rem]' : 'start-0.5',
            )}
          />
        </button>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-xs text-muted-foreground">
        {field.label}
      </label>
      <input
        id={id}
        type={field.type}
        value={String(value)}
        min={field.min}
        step={field.step}
        dir="ltr"
        onChange={(e) => onChange(field.type === 'number' ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value)}
        className="h-10 rounded-lg border border-white/[0.08] bg-[#0a0a0a] px-3 text-start font-mono text-sm text-foreground outline-none transition-all focus:border-primary/50 focus:shadow-[0_0_0_3px_rgb(34_211_238/0.12)]"
      />
    </div>
  )
}
